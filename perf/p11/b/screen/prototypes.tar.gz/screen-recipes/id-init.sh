set -euo pipefail
until rg -qx 'built i128-t256-o3' build/p11/geometry-builds.log; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
    sleep 5
done
python3 - <<'PY'
from pathlib import Path
p=Path('ggml/src/ggml-cuda/mmq.cuh');s=p.read_text()
assert 'config.I = ' not in s
a=s.index('#pragma unroll',s.index('    extern __shared__ int ids_dst_shared[]; // Stored'))
b=s.index('    // The fused kernel',a)
old=s[a:b].rstrip()
new='    if (!ids_dst) {\n'+'\n'.join(('    '+line if line and not line.startswith('#') else line) for line in old.split('\n'))+'\n    }\n\n'
s=s[:a]+new+s[b:]
p.write_text(s)
PY
git diff -- ggml/src/ggml-cuda/mmq.cuh >perf/p11/b/screen/id-init.patch
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >build/p11/id-build.log 2>&1
cp -a build/p11/base-bin build/p11/id-bin
cp -L build/bin/libggml-cuda.so.1 build/p11/id-bin/
for leg in old1 new1 new2 old2; do
    export B_LIBS="$PWD/build/p11/bias-bin"
    if [[ $leg == new* ]]; then B_LIBS="$PWD/build/p11/id-bin"; fi
    out="perf/p11/b/screen/id-$leg.json"
    perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p 4096 -n 0 -r 3 >"$out" 2>"build/p11/screen/id-$leg.log"
    python3 -c 'import json,sys;print(sys.argv[1],json.load(open(sys.argv[1]))[0]["avg_ts"],flush=True)' "$out"
done
