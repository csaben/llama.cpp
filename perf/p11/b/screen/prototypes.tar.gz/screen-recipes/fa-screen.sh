set -euo pipefail
python3 build/p11/fa-screen.py
git diff -- ggml/src/ggml-cuda/fattn-mma-f16.cuh >perf/p11/b/screen/fa-screen.patch
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >build/p11/fa-build.log 2>&1
cp -a build/p11/base-bin build/p11/fa-bin
cp -L build/bin/libggml-cuda.so.1 build/p11/fa-bin/
mkdir -p perf/p11/b/screen/fa
for depth in 16384 65536; do
    for leg in old1 new1 new2 old2; do
        export B_LIBS="$PWD/build/p11/verify-bin"
        if [[ $leg == new* ]]; then B_LIBS="$PWD/build/p11/fa-bin"; fi
        out="perf/p11/b/screen/fa/$depth-$leg.json"
        perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p "$depth" -n 0 -r 1 >"$out" 2>"build/p11/screen/fa-$depth-$leg.log"
        python3 -c 'import sys,json;print(sys.argv[1],json.load(open(sys.argv[1]))[0]["avg_ts"],flush=True)' "$out"
    done
done
