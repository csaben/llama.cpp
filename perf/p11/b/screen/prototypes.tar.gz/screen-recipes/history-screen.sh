set -euo pipefail
python3 build/p11/history-screen.py
git diff -- common/speculative.cpp > perf/p11/b/screen/history-screen.patch
obj=common/CMakeFiles/llama-common.dir
make -f "$obj/build.make" -C build "$obj/speculative.cpp.o" >build/p11/history-build.log 2>&1
(cd build/common && cmake -E cmake_link_script CMakeFiles/llama-common.dir/link.txt) >>build/p11/history-build.log 2>&1
cp -a build/p11/base-bin build/p11/history-bin
cp -L build/bin/libllama-common.so.1 build/p11/history-bin/
d=build/p11/history-screen
export B_LIBS="$PWD/build/p11/history-bin"
for budget in 384 3000; do
    reps=1
    if [[ $budget == 384 ]]; then reps=3; fi
    for leg in old1 new1 new2 old2; do
        width=6
        if [[ $leg == new* ]]; then width=7; fi
        perf/p11/b/gpu.sh perf/p11/b/run.sh probe "$d/$budget" "$leg" "$width" code,edit,prose,agent "$reps" "$budget"
        if [[ $leg != old1 ]]; then SPEC_REQUIRE_IDS=1 SPEC_KINDS=code,edit,prose,agent python3 perf/p6/r4_cmp.py "$d/$budget" old1 "$leg" >"$d/$budget/$leg.equal"; fi
    done
done
