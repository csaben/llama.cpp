set -euo pipefail
d=perf/p11/b/screen/attention
mkdir -p "$d"
# One same-build logit check per candidate, with attention at short and deep positions.
for depth in 200 16384; do
    for variant in base occupancy6 occupancy14 longer_steps external_scan packed_wide window_tile no_pack base_repeat; do
        opts=()
        case $variant in
            occupancy6) opts=(IK_ATTN_MMA_SPLITS=6) ;;
            occupancy14) opts=(IK_ATTN_MMA_SPLITS=14) ;;
            longer_steps) opts=(IK_ATTN_MMA_SPW=2) ;;
            external_scan) opts=(IK_ATTN_SCAN_MIN=2048 IK_WINDOW_SCAN_MIN=2048) ;;
            packed_wide) opts=(B_WINDOW_COLS=2) ;;
            window_tile) opts=(IK_WINDOW_TILE_ROWS=4 B_WINDOW_COLS=0) ;;
            no_pack) opts=(B_WINDOW_COLS=0) ;;
        esac
        log="build/p11/screen/attn-$depth-$variant.log"
        if ! env "${opts[@]}" MR_RS_A=0 MR_RS=6 MR_SIZES=2,3,4,5,6,7 MR_ROLLBACK=0 MR_CTX=20500 perf/p11/b/gpu.sh perf/p11/b/run.sh mr perf/ppl.txt "$depth" 72 >"$log" 2>&1; then
            rg -q 'rows differ from single-token decode' "$log" || exit 1
        fi
        rg 'rows differ|single token:|window of ' "$log" >"$d/$depth-$variant.txt"
    done
done
for mode in 1 3; do
    log="build/p11/screen/mma-$mode.log"
    B_MMA=$mode MR_RS_A=0 MR_RS=6 MR_SIZES=2,3,4,5,6,7 MR_ROLLBACK=0 MR_CTX=8192 perf/p11/b/gpu.sh perf/p11/b/run.sh mr perf/ppl.txt 200 72 >"$log" 2>&1
    rg 'rows differ|single token:|window of ' "$log" >"$d/mma-$mode.txt"
done
