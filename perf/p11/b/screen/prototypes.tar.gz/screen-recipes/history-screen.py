from pathlib import Path
p=Path('common/speculative.cpp')
s=p.read_text()
a='''        if (dev_anchor && use_dev_features && round && atoi(round) && this->params.p_min == 0 && head_n <= ADAPT_T_MAX && head_n < block_size - 1 &&'''
assert s.count(a)==1
s=s.replace(a,'''        const char * policy = getenv("LLAMA_DSPARK_POLICY");
        const char * graphs = getenv("LLAMA_DSPARK_GRAPHS");
        const bool use_policy = policy ? atoi(policy) != 0 : adapt.on;
        const bool wide_history = head_n == block_size - 1 && head_n == 7 && this->params.n_min < 7 &&
                use_policy && graphs && atoi(graphs);
        if (dev_anchor && use_dev_features && round && atoi(round) && this->params.p_min == 0 && head_n <= ADAPT_T_MAX && (head_n < block_size - 1 || wide_history) &&''')
a='''            const char * policy = getenv("LLAMA_DSPARK_POLICY");
            const char * graphs = getenv("LLAMA_DSPARK_GRAPHS");
            const bool use_policy = policy ? atoi(policy) != 0 : adapt.on;
'''
assert s.count(a)==1;s=s.replace(a,'')
a='''        const int probe = std::min(limit, 6);'''
assert s.count(a)==1;s=s.replace(a,'        const int probe = std::min(limit, 7);')
p.write_text(s)
