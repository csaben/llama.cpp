from pathlib import Path
import os, shutil, subprocess
p=Path('ggml/src/ggml-cuda/mmq.cuh')
s=p.read_text()
a='''    auto config = ggml_cuda_mmq_get_config_ampere(type, J, fallback);'''
assert s.count(a)==1
d=Path('build/p11')
out=Path('perf/p11/b/screen/geometry')
out.mkdir(parents=True,exist_ok=True)
previous=s
for rows,threads,occ in [(64,128,1),(64,128,3),(64,128,5),(32,64,4),(128,256,2),(128,256,3)]:
    if any(x.exists() for x in [Path('perf/STOP'),Path('/home/arelius/llama.cpp-fast/perf/STOP')]): break
    assert p.read_text()==previous
    name=f'i{rows}-t{threads}-o{occ}'
    extra=f'''
    if (!fallback && J == 32 && (type == GGML_TYPE_Q2_K || type == GGML_TYPE_Q2_0)) {{
        config.I = {rows};
        config.nthreads = {threads};
        config.occupancy = {occ};
    }}'''
    previous=s.replace(a,a+extra)
    p.write_text(previous)
    with (d/f'geometry-{name}.log').open('w') as f:
        subprocess.run(['cmake','--build','build','-j8','--target','ggml-cuda'],env={**os.environ,'CUDA_DEVICE_ORDER':'PCI_BUS_ID','CUDA_VISIBLE_DEVICES':'0'},stdout=f,stderr=subprocess.STDOUT,check=True)
    lib=d/f'geom-{name}'
    shutil.copytree(d/'base-bin',lib,copy_function=os.link)
    (lib/'libggml-cuda.so.1').unlink()
    shutil.copy2('build/bin/libggml-cuda.so.1',lib/'libggml-cuda.so.1')
    print('built',name,flush=True)
assert p.read_text()==previous
p.write_text(s)
