set -euo pipefail
until [[ -f build/p11/screen-bin/libggml-cuda.so.1 ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
    sleep 5
done
python3 build/p11/verify-screen.py
git diff -- ggml/src/ggml-cuda/mmvq.cu >perf/p11/b/screen/verify-screen.patch
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j6 --target ggml-cuda >build/p11/verify-build.log 2>&1
cp -a build/p11/base-bin build/p11/verify-bin
cp -L build/bin/libggml-cuda.so.1 build/p11/verify-bin/
mkdir -p perf/p11/b/screen/verify
for v in old1 v0 v1 v2 v3 v3-repeat old2; do
    export B_LIBS="$PWD/build/p11/verify-bin" P11B_VERIFY=${v:1:1}
    if [[ $v == old* ]]; then B_LIBS="$HOME/inkling-live-bin-p9-72fd097"; fi
    log="build/p11/screen/verify-$v.log"
    MR_RS_A=0 MR_RS=6 MR_SIZES=2,3,4,5,6,7 MR_ROLLBACK=0 MR_CTX=8192 perf/p11/b/gpu.sh perf/p11/b/run.sh mr perf/ppl.txt 200 144 >"$log" 2>&1
    rg 'single token:|window of |rows differ' "$log" >"perf/p11/b/screen/verify/$v.txt"
done
