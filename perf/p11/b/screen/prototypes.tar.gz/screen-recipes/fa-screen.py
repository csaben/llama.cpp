from pathlib import Path
p=Path('ggml/src/ggml-cuda/fattn-mma-f16.cuh')
s=p.read_text()
a='''                values[i] = __hmul2(__halves2half2(__int2half_rn(block.qs[j]), __int2half_rn(block.qs[j + 1])), scale);'''
assert s.count(a)==1
s=s.replace(a,'''#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ == 860
                uint16_t pair;
                memcpy(&pair, block.qs + j, sizeof(pair));
                const uint32_t biased = __byte_perm(pair ^ 0x8080u, 0x64u, 0x4140u);
                half2 packed;
                memcpy(&packed, &biased, sizeof(packed));
                values[i] = __hmul2(__hsub2_rn(packed, __float2half2_rn(1152.0f)), scale);
#else
'''+a+'''
#endif''')
p.write_text(s)
