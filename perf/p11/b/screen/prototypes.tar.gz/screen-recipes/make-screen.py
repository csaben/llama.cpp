from pathlib import Path
p=Path('ggml/src/ggml-cuda/mmq.cu')
s=p.read_text()
a='            ncols_opt = (ne12*n_expert_used + ne02 - 1) / ne02;'
assert s.count(a)==1
s=s.replace(a,a+'''
            if (cc == GGML_CUDA_CC_AMPERE_GA10X && ne12 >= 512 &&
                    (src0->type == GGML_TYPE_Q2_K || src0->type == GGML_TYPE_Q2_0)) {
                static const int k = getenv("P11B_Q2K_J") ? atoi(getenv("P11B_Q2K_J")) : 0;
                static const int z = getenv("P11B_Q20_J") ? atoi(getenv("P11B_Q20_J")) : 0;
                const int width = src0->type == GGML_TYPE_Q2_K ? k : z;
                if (width > 0) {
                    ncols_opt = width;
                }
            }''')
p.write_text(s)
p=Path('ggml/src/ggml-cuda/mmq.cuh')
s=p.read_text()
a='    const bool tile_experts = cc == GGML_CUDA_CC_AMPERE_GA10X'
assert s.count(a)==1
s=s.replace(a,'''    static const int tile_min = getenv("P11B_TILE_MIN") ? atoi(getenv("P11B_TILE_MIN")) : 90;
    const bool tile_experts = cc == GGML_CUDA_CC_AMPERE_GA10X''')
s=s.replace('&& tiles_efficiency_percent >= 90 && args.ntj <= 65535;', '&& tiles_efficiency_percent >= tile_min && args.ntj <= 65535;')
a='    const dim3 block_nums_stream_k(nblocks_stream_k, 1, 1);'
assert s.count(a)==1
s=s.replace(a,'''    if (cc == GGML_CUDA_CC_AMPERE_GA10X && args.ids_dst && args.ncols_dst >= 512 && (type == GGML_TYPE_Q2_K || type == GGML_TYPE_Q2_0)) {
        static const int waves = getenv("P11B_STREAM_WAVES") ? atoi(getenv("P11B_STREAM_WAVES")) : 0;
        if (waves > 0) {
            nblocks_stream_k = std::min(nsm*waves, nwork);
        }
    }
'''+a)
p.write_text(s)
