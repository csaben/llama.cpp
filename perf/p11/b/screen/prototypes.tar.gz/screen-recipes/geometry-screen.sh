set -euo pipefail
d=perf/p11/b/screen/geometry
for name in bias-bin geom-i64-t128-o1 geom-i64-t128-o3 geom-i64-t128-o5 geom-i32-t64-o4 geom-i128-t256-o2 geom-i128-t256-o3 bias-bin; do
    while [[ $name == geom-* ]] && ! rg -qx "built ${name#geom-}" build/p11/geometry-builds.log; do
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
        sleep 5
    done
    label=$name
    if [[ -e "$d/$label.json" ]]; then label="$label-repeat"; fi
    B_LIBS="$PWD/build/p11/$name" perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p 4096 -n 0 -r 3 >"$d/$label.json" 2>"build/p11/screen/$label.log"
    python3 -c 'import json,sys;print(sys.argv[1],json.load(open(sys.argv[1]))[0]["avg_ts"],flush=True)' "$d/$label.json"
done
