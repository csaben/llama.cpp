set -euo pipefail
python3 build/p11/bias-screen.py
git diff -- ggml/src/ggml-cuda/inkling.cu >perf/p11/b/screen/bias-screen.patch
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >build/p11/bias-build.log 2>&1
cp -a build/p11/base-bin build/p11/bias-bin
cp -L build/bin/libggml-cuda.so.1 build/p11/bias-bin/
mkdir -p perf/p11/b/screen/bias
export B_LIBS="$PWD/build/p11/bias-bin"
for pair in 0 1; do
    for t in 256 128 512 1024; do
        out="perf/p11/b/screen/bias/pp16k-p$pair-t$t.json"
        P11B_BIAS_PAIR=$pair P11B_BIAS_THREADS=$t perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p 16384 -n 0 -r 2 >"$out" 2>"build/p11/screen/bias-$pair-$t.log"
        python3 -c 'import json,sys;print(sys.argv[1],json.load(open(sys.argv[1]))[0]["avg_ts"],flush=True)' "$out"
    done
done
