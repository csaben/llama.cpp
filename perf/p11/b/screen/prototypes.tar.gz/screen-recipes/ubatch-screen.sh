set -euo pipefail
mkdir -p perf/p11/b/screen/ubatch
for ub in 512 256 384 640 768 1024 1536 2048; do
    for depth in 4096 16384; do
        out="perf/p11/b/screen/ubatch/pp$depth-ub$ub.json"
        B_UBATCH=$ub perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p "$depth" -n 0 -r 2 >"$out" 2>"build/p11/screen/ub$ub-$depth.log"
        python3 -c 'import sys,json; print(sys.argv[1], json.load(open(sys.argv[1]))[0]["avg_ts"],flush=True)' "$out"
    done
done
