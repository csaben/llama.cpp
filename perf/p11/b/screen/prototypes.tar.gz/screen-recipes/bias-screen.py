from pathlib import Path
p=Path('ggml/src/ggml-cuda/inkling.cu');s=p.read_text()
a='static __global__ void rel_bias_four_heads('
assert s.count(a)==1;s=s.replace(a,'template <bool pairs>\n'+a)
a='''    for (int kv = threadIdx.x; kv < n_kv; kv += blockDim.x) {
        const unsigned p = pos[(int64_t) t*n_kv + kv];'''
assert s.count(a)==1
s=s.replace(a,'''    if constexpr (pairs) {
        const auto * positions = (const uint2 *) (pos + (int64_t) t*n_kv);
        const auto * masks = (const half2 *) (mask + t*mask_ne0);
        for (int k = threadIdx.x; k < n_kv/2; k += blockDim.x) {
            const uint2 p = positions[k];
            const float2 m = __half22float2(masks[k]);
#pragma unroll
            for (int h = 0; h < 4; ++h) {
                const float x = p.x < 1024 ? bias[h][p.x] : 0.0f;
                const float y = p.y < 1024 ? bias[h][p.y] : 0.0f;
                ((half2 *) (dst + ((int64_t) (h0+h)*n_tok + t)*n_kv))[k] = __floats2half2_rn((x - sk[h]) + m.x, (y - sk[h]) + m.y);
            }
        }
        return;
    }
'''+a)
a='''        rel_bias_four_heads<<<dim3(n_head/4, n_tok), 256, 0, stream>>>(r_d, (const float4 *) table_d, sinks_d,
            pos_d, (const half *) mask->data, (half *) dst->data, n_head, n_tok, n_kv, mask_ne0, sinks_nb1);'''
assert s.count(a)==1
s=s.replace(a,'''        static const int threads = getenv("P11B_BIAS_THREADS") ? std::clamp(atoi(getenv("P11B_BIAS_THREADS")), 32, 1024) : 256;
        static const bool pair = getenv("P11B_BIAS_PAIR") && atoi(getenv("P11B_BIAS_PAIR"));
        if (pair && n_kv % 2 == 0 && mask_ne0 % 2 == 0 && (uintptr_t) pos_d % 8 == 0 &&
                (uintptr_t) mask->data % 4 == 0 && (uintptr_t) dst->data % 4 == 0) {
            rel_bias_four_heads<true><<<dim3(n_head/4, n_tok), threads, 0, stream>>>(r_d, (const float4 *) table_d, sinks_d,
                pos_d, (const half *) mask->data, (half *) dst->data, n_head, n_tok, n_kv, mask_ne0, sinks_nb1);
        } else {
            rel_bias_four_heads<false><<<dim3(n_head/4, n_tok), threads, 0, stream>>>(r_d, (const float4 *) table_d, sinks_d,
                pos_d, (const half *) mask->data, (half *) dst->data, n_head, n_tok, n_kv, mask_ne0, sinks_nb1);
        }''')
p.write_text(s)
