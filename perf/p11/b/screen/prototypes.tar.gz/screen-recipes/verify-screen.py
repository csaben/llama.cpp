from pathlib import Path
p=Path('ggml/src/ggml-cuda/mmvq.cu');s=p.read_text()
a=s.index('    // the pairs of the window with this block\'s expert')
b=s.index('\n    const uint8_t * wa',a)
s=s[:a]+'''    const int e = ids[(slot & 7) + (slot >> 3)*ids_stride];
    uint64_t mask = 1ull << slot;
    if constexpr (NC > 1) {
        const int lo = (uint32_t) lane < nslots ? ids[(lane & 7) + (lane >> 3)*ids_stride] : -1;
        mask = __ballot_sync(0xffffffffu, lo == e);
        if constexpr (NC > 4) {
            const int hi = (uint32_t) lane + 32 < nslots ? ids[(lane & 7) + ((lane + 32) >> 3)*ids_stride] : -2;
            mask |= (uint64_t) __ballot_sync(0xffffffffu, hi == e) << 32;
        }
        if (__ffsll((long long) mask) - 1 != (int) slot) {
            return;
        }
    }
''' +s[b:]
a=s.index('        const int lo = (uint32_t) lane',s.index('static __global__ void ik_q2k_moe('))
b=s.index('        if (__ffsll',a)
s=s[:a]+'''        const int lo = (uint32_t) lane < nslots ? ids[(lane & 7) + (lane >> 3)*ids_stride] : -1;
        e = ids[(slot & 7) + (slot >> 3)*ids_stride];
        mask = __ballot_sync(0xffffffffu, lo == e);
        if constexpr (NC > 4) {
            const int hi = (uint32_t) lane + 32 < nslots ? ids[(lane & 7) + ((lane + 32) >> 3)*ids_stride] : -2;
            mask |= (unsigned long long) __ballot_sync(0xffffffffu, hi == e) << 32;
        }
'''+s[b:]
a='            if (src0->type == GGML_TYPE_Q2_K && (ik_mma_mode() & 2)) {'
s=s.replace(a,'''            static const int narrow = getenv("P11B_VERIFY") ? atoi(getenv("P11B_VERIFY")) : 0;
'''+a)
a='                if (n_tok == 1) { IK_Q2K_MOE(1); } else if (n_tok == 2) { IK_Q2K_MOE(2); } else if (n_tok <= 4) { IK_Q2K_MOE(4); } else { IK_Q2K_MOE(8); }'
assert s.count(a)==1
s=s.replace(a,'''                if (narrow & 1 && n_tok == 3) { IK_Q2K_MOE(3); }
                else if (narrow & 1 && n_tok == 5) { IK_Q2K_MOE(5); }
                else if (narrow & 1 && n_tok == 6) { IK_Q2K_MOE(6); }
                else if (narrow & 1 && n_tok == 7) { IK_Q2K_MOE(7); }
                else '''+a.strip())
a='                if (n_tok == 1) { IK_MMA_MOE(GGML_TYPE_Q2_0, 1); } else { IK_MMA_MOE(GGML_TYPE_Q2_0, 8); }'
assert s.count(a)==1
s=s.replace(a,'''                if (n_tok == 1) { IK_MMA_MOE(GGML_TYPE_Q2_0, 1); }
                else if (narrow & 2 && n_tok <= 4) { IK_MMA_MOE(GGML_TYPE_Q2_0, 4); }
                else { IK_MMA_MOE(GGML_TYPE_Q2_0, 8); }''')
p.write_text(s)
