from pathlib import Path
p=Path('common/speculative.cpp')
s=p.read_text()
a='''            const double prior = plain*adaptive_shape(t);'''
assert s.count(a)==1
s=s.replace(a,'''            static const double verify_scale = []() {
                const char * value = getenv("P11B_VERIFY_SCALE");
                return value ? std::clamp(atof(value), 0.5, 1.5) : 1.0;
            }();
            const double shape = adaptive_shape(t);
            const double prior = plain*(t < 2 ? shape : 1 + (shape - 1)*verify_scale);''')
a='''                head_n = std::min(head_n, std::max(3, this->params.n_min));'''
assert s.count(a)==1
s=s.replace(a,'''                const char * width = getenv("P11B_MODEL_CAP");
                const int cap = width ? std::clamp(atoi(width), 2, 6) : 3;
                head_n = std::min(head_n, std::max(cap, this->params.n_min));''')
p.write_text(s)
