set -euo pipefail
until [[ -s perf/p11/b/baseline/short/equality.txt ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
    sleep 5
done
python3 build/p11/policy-screen.py
git diff -- common/speculative.cpp >perf/p11/b/screen/policy-screen.patch
# Compile the one changed object and relink the common library, independent of CUDA experiments.
obj=common/CMakeFiles/llama-common.dir
make -f "$obj/build.make" -C build "$obj/speculative.cpp.o" >build/p11/policy-build.log 2>&1
(cd build/common && cmake -E cmake_link_script CMakeFiles/llama-common.dir/link.txt) >>build/p11/policy-build.log 2>&1
cp -a build/p11/base-bin build/p11/policy-bin
cp -L build/bin/libllama-common.so.1 build/p11/policy-bin/
export B_LIBS="$PWD/build/p11/policy-bin"
d=build/p11/policy-screen
for budget in 384 3000; do
    for pair in 3:1.00 3:0.70 3:0.85 4:0.85 4:1.00 5:0.85 6:0.85 3:1.15 3:1.00; do
        export P11B_MODEL_CAP=${pair%:*} P11B_VERIFY_SCALE=${pair#*:}
        label="w$P11B_MODEL_CAP-s$P11B_VERIFY_SCALE"
        if [[ -e "$d/$budget/$label.txt" ]]; then label="$label-repeat"; fi
        reps=2
        if [[ $budget == 3000 ]]; then reps=1; fi
        perf/p11/b/gpu.sh perf/p11/b/run.sh probe "$d/$budget" "$label" 6 code,edit,prose,agent "$reps" "$budget"
        spec=perf/p11/b/baseline/short
        if [[ $budget == 3000 ]]; then
            for kind in code edit prose agent; do
                for ext in ids json; do cmp "$d/$budget/$label.$kind.$ext" "$spec/n0.$kind.$ext"; done
            done
        fi
    done
done
