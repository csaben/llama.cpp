set -euo pipefail
export B_LIBS="$PWD/build/p11/screen-bin"
d=perf/p11/b/screen
pp() {
    perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p 4096 -n 0 -r 2 >"$d/pp-$1.json" 2>"build/p11/screen/$1.log"
    python3 - "$d/pp-$1.json" <<'PY'
import sys,json
print(sys.argv[1], round(json.load(open(sys.argv[1]))[0]['avg_ts'],2), flush=True)
PY
}
pp base0
for j in 8 16 24 40 48 64 80 96; do
    P11B_Q2K_J=$j pp "q2k-j$j"
    P11B_Q20_J=$j pp "q20-j$j"
done
P11B_TILE_MIN=101 pp stream-all
for waves in 1 2 4 8; do
    P11B_TILE_MIN=101 P11B_STREAM_WAVES=$waves pp "stream-waves$waves"
done
pp base1
