"""Allow the p9 trace reference to be checkpointed between GPU lock acquisitions."""
from pathlib import Path
import subprocess

work = Path('build/p11/managed')
source = subprocess.check_output(['git','show','72fd097e:perf/p6/mr_check.cpp'], text=True)
start = source.index('    {\n        llama_context * ctx = make_ctx(model, getenv("MR_RS_A")')
end = source.index('    llama_context * ctx = make_ctx(model);', start)
original = source[start:end]
block = original.replace('    {\n', '''    if (const char * path = getenv("P11_REFERENCE")) {
        std::ifstream saved(path, std::ios::binary);
        if (!saved.read(reinterpret_cast<char *>(ref.data()), ref.size()*sizeof(float)) || saved.peek() != EOF) return 1;
    } else {
''', 1)
block = block.replace('        for (size_t i = 0; i < gen0; ++i) {', '''        const int first = getenv("P11_REF_START") ? atoi(getenv("P11_REF_START")) : n_prompt;
        const int last = getenv("P11_REF_END") ? atoi(getenv("P11_REF_END")) : std::min(lim, n_pos);
        if (!ctx || first < n_prompt || last <= first || last > std::min(lim, n_pos)) return 1;
        if (first > n_prompt) {
            std::vector<llama_token> tokens(first);
            size_t count = 0;
            const char * state = getenv("P11_STATE_LOAD");
            if (!state || !llama_state_load_file(ctx, state, tokens.data(), tokens.size(), &count) ||
                count != tokens.size() || !std::equal(tokens.begin(), tokens.end(), fin.begin())) return 1;
        }
        for (size_t i = 0; first == n_prompt && i < gen0; ++i) {''')
block = block.replace('int p = n_prompt; p < n_pos && p < lim;', 'int p = first; p < last;')
block = block.replace('        llama_free(ctx);', '''        if (const char * output = getenv("P11_REF_OUT")) {
            if (const char * state = getenv("P11_STATE_SAVE")) {
                if (!llama_state_save_file(ctx, state, fin.data(), last)) return 1;
            }
            std::ofstream out(output, std::ios::binary);
            const float * from = ref.data() + size_t(first-n_prompt)*n_vocab;
            out.write(reinterpret_cast<const char *>(from), size_t(last-first)*n_vocab*sizeof(float));
            out.close();
            llama_free(ctx);
            if (!out) return 1;
            printf("single-token reference positions %d through %d, %d vocabulary entries per row\\n", first, last-1, n_vocab);
            return 0;
        }
        llama_free(ctx);''')
assert 'first; p < last' in block and source.count(original)==1
path=work/'mr-split.cpp'
path.write_text('#include <algorithm>\n'+source.replace(original,block))
subprocess.run(['g++','-O2','-std=c++17','-Wno-deprecated-declarations',str(path),'-Iinclude','-Iggml/include','-Lbuild/bin','-lllama','-lggml','-lggml-base','-o',str(work/'mr-split')],check=True)
