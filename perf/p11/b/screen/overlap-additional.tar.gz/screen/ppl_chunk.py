"""Build a p9 perplexity frontend that evaluates one independently reset chunk and prints its loss sums."""
from pathlib import Path
import subprocess

work = Path('build/p11/managed')
work.mkdir(parents=True, exist_ok=True)
source = subprocess.check_output(['git','show','72fd097e:tools/perplexity/perplexity.cpp'], text=True)
start = '        const int start =     i * n_ctx;'
assert source.count(start) == 2
source = source.replace(start, '''        const int chunk_offset = getenv("P11_PPL_CHUNK") ? atoi(getenv("P11_PPL_CHUNK")) : 0;
        GGML_ASSERT(n_chunk == 1 && n_seq == 1 && chunk_offset >= 0 && chunk_offset < n_chunk_max);
        const int start = (i + chunk_offset)*n_ctx;''', 1)
pos = source.index('    nll2 /= count;', source.index('static results_perplexity perplexity(llama_context'))
source = source[:pos] + '    fprintf(stderr, "P11_CHUNK_LOSS %d %.17g %.17g\\n", count, nll, nll2);\n' + source[pos:]
path = work/'perplexity-chunk.cpp'
path.write_text(source)
subprocess.run(['g++','-O3','-DNDEBUG','-std=c++17','-DLLAMA_SUBPROCESS','-DGGML_USE_CUDA','-DGGML_USE_CPU',
                '-Itools/perplexity','-Icommon','-Iinclude','-Iggml/include','-Ivendor','tools/perplexity/main.cpp',str(path),
                '-Lbuild/bin','-lllama-common','-lllama','-lggml','-lggml-base','-pthread','-o',str(work/'ppl-chunk')],check=True)
