set -euo pipefail
export BRACKET_NEW="$PWD/build/p11/release-bin" LLAMA_DSPARK_FULL_RATE=1
d=perf/p11/b/release
mkdir -p "$d"
case "$1" in
    matrix) B_LIBS="$BRACKET_NEW" bash perf/p11/b/matrix.sh build/p11/matrix-new ;;
    served|synthetic) bash perf/p11/b/crossover.sh "$1" build/p11/paired ;;
    checks) B_LIBS="$BRACKET_NEW" bash perf/p11/b/checks.sh "$d/checks" ;;
    baseline) bash perf/p11/b/checks.sh perf/p11/b/baseline/checks ;;
    long) bash perf/p11/b/long-bracket.sh 131072 127872 release-128k p9-128k ;;
    logits) bash perf/p11/b/logits.sh "$d/logits" ;;
    ppl)
        export B_LIBS="$BRACKET_NEW"
        B_MR=0 B_MMA=0 perf/p11/b/gpu.sh perf/p11/b/run.sh ppl -c 1024 -b 1024 -ub 1 --chunks 2 >"$d/decode-default.log" 2>&1
        rg 'Final estimate:' "$d/decode-default.log" >"$d/decode-default.txt"
        bash perf/p11/b/ppl-reference.sh "$d/historical-model" ;;
esac
