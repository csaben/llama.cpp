set -euo pipefail
leg=$1 prior=$2
out=perf/p11/b/quality/decode-native
mkdir -p "$out"
export B_LIBS="$HOME/inkling-live-bin-p9-72fd097" B_MMA=3 B_WINDOW_COLS=1 B_MIN_FREE_MIB=11500
if [[ $leg == new* ]]; then export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2; fi
export B_PPL_TICKET=$leg
while [[ ! -s "$out/$leg.txt" ]]; do
    status=0
    perf/p11/b/gpu.sh bash -ec '
        if [[ $2 != first && ! -s "$1/$2.txt" ]]; then exit 76; fi
        exec perf/p11/b/run.sh ppl -c 1024 -b 1024 -ub 1 --chunks 2
    ' b-ppl "$out" "$prior" >"build/p11/ppl-ticket-$leg.log" 2>&1 || status=$?
    if [[ $status == 76 ]]; then continue; fi
    if [[ $status != 0 ]]; then exit "$status"; fi
    rg 'Final estimate: PPL' "build/p11/ppl-ticket-$leg.log" >"$out/$leg.txt"
done
