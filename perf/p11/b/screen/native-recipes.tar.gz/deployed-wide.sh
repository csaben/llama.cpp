set -euo pipefail
export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1
export MR_RS_A=0 MR_RS=6 MR_SIZES=2,3,4,5,6,7 MR_RAND=37 MR_PLAIN_PCT=0 MR_CTX=34816
input=build/p11/deployed-wide-input
cat perf/ppl.txt perf/ppl.txt >"$input"
for depth in 200 4096 16384 32768; do
    out="perf/p11/b/narrow/checks/wide-2-$depth.log"
    if rg -q ' 0 rows differ from single-token decode, max \|logit diff\| 0$' "$out" 2>/dev/null; then continue; fi
    log="build/p11/deployed-wide-$depth.log"
    perf/p11/b/gpu.sh perf/p11/b/run.sh mr "$input" "$depth" 64 >"$log" 2>&1
    rg ' 0 rows differ from single-token decode, max \|logit diff\| 0$' "$log"
    cp "$log" "$out"
done
