set -euo pipefail
d=perf/p11/b/quality
mkdir -p "$d"
for mode in prefill decode; do
    args=(-c 2048 -b 2048 -ub 512 --chunks 8)
    if [[ $mode == decode ]]; then args=(-c 1024 -b 1024 -ub 1 --chunks 2); fi
    for leg in old1 new1 new2 old2; do
        export B_LIBS="$HOME/inkling-live-bin-p9-72fd097" B_MMA=3 B_WINDOW_COLS=1
        if [[ $leg == new* ]]; then B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2; fi
        log="build/p11/primary-ppl-$mode-$leg.log"
        perf/p11/b/gpu.sh perf/p11/b/run.sh ppl "${args[@]}" >"$log" 2>&1
        rg 'Final estimate: PPL' "$log" >"$d/$mode-$leg.txt"
    done
    python3 - "$d" "$mode" <<'PY'
from pathlib import Path
import re,sys
d=Path(sys.argv[1]);mode=sys.argv[2]
vals=[float(re.search(r'PPL = (\S+)',(d/f'{mode}-{leg}.txt').read_text())[1]) for leg in ['old1','new1','new2','old2']]
assert vals[0]==vals[3] and vals[1]==vals[2] and abs(vals[1]/vals[0]-1)<=0.001,vals
print(mode,vals)
PY
done
