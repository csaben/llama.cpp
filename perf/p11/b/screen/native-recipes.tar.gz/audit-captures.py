from pathlib import Path
import csv
import hashlib
import json
import re
import tarfile

base=Path('perf/p11/b/baseline')
short=base/'short'
for prompt in ('code','edit','prose','agent'):
    for ext in ('json','ids'):
        a=(short/f'n0.{prompt}.{ext}').read_bytes()
        b=(short/f'n6.{prompt}.{ext}').read_bytes()
        assert a==b
        if ext=='ids':
            assert len(a)==3000*4
            print(f'short {prompt} 3000 IDs, identical complete message, ID SHA256 {hashlib.sha256(b).hexdigest()}')
with tarfile.open('perf/p11/b/long/p9-captures.tar.gz') as t:
    names=[n for n in t.getnames() if '-dspark-' in n]
    assert len(names)==3
    for draft in names:
        plain=draft.replace('-dspark-','-plain-')
        old,new=[json.load(t.extractfile(n)) for n in (plain,draft)]
        assert old['message']==new['message'] and old['ids']==new['ids'] and len(old['ids'])==3000
        assert new['timings']['draft_n_accepted']>0
        print(f"{draft} identical complete message and 3000 IDs, {old['timings']['predicted_per_second']:.2f}/{new['timings']['predicted_per_second']:.2f} tok/s plain/DSpark")
with tarfile.open(base/'initial-matrix.tar.gz') as t:
    with (base/'initial-matrix.tsv').open() as src:
        rows=list(csv.DictReader(src,delimiter='\t'))
    assert len(rows)==36
    replies=ids=0
    for row in rows:
        prefix=row['suite']+'/'+row['budget']+'/'
        prompt=row['prompt'];setting=row['row'];reps=int(row['replies']);budget=int(row['budget'])
        for ext,key in [('ids','ids_sha256'),('json','message_sha256')]:
            old=t.extractfile(prefix+'plain.'+prompt+'.'+ext).read()
            new=t.extractfile(prefix+setting+'.'+prompt+'.'+ext).read()
            assert new==old and hashlib.sha256(new).hexdigest()==row[key],row
            if ext=='ids':assert len(new)==4*budget
        lines=t.extractfile(prefix+setting+'.txt').read().decode().splitlines()
        line,=[s for s in lines if s.split()[1]==prompt]
        assert len(re.fullmatch(r'.* runs ([0-9/]+)',line)[1].split('/'))==reps
        replies+=reps;ids+=int(row['reply_ids'])
    assert (replies,ids)==(108,41472)
    print(f'initial 384-token matrix: {len(rows)} drafted cells, {replies} replies, {ids} IDs. All hashes, repeat counts, messages and IDs matched their controls.')
