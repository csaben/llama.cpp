set -euo pipefail
for version in p9 combined narrow; do
    lib="$PWD/build/p11/$version-bin"; mma=7
    if [[ $version == p9 ]]; then lib="$HOME/inkling-live-bin-p9-72fd097"; mma=3; fi
    mkdir -p "perf/p11/b/screen/ops/$version"
    for group in window prefill; do
        re='name=(gate|down)-[1-8],'
        expected=16
        if [[ $group == prefill ]]; then re='name=(gate|down)-512,'; expected=2; fi
        log="build/p11/ops/$version-$group.log"
        B_MIN_FREE_MIB=1100 B_LIBS="$lib" B_MMA=$mma perf/p11/b/gpu.sh perf/p11/b/run.sh ops --test-file perf/p11/b/screen/window.ops -p "$re" >"$log" 2>&1
        out="perf/p11/b/screen/ops/$version/$group.txt"
        sed -E 's/\x1B\[[0-9;]*[mK]//g' "$log" | rg 'tests passed|Backend CUDA0:|FAIL' >"$out"
        rg -q " $expected/$expected tests passed" "$out"
    done
done
