set -euo pipefail
kind=$1 leg=$2
root=build/p11/bench-grid
d="$root/tail"
mkdir -p "$d"
name="$d/$kind-timed-$leg"
prior="$root/$kind-timed-new1"
if [[ $leg == old2 ]]; then prior="$d/$kind-timed-new2"; fi
if [[ $kind == tg ]]; then args=(-p 0 -n 128 -d 0,4096,16384,32768,65536); count=5; else args=(-p 4096,16384,65536 -n 0); count=3; fi
export B_LIBS="$HOME/inkling-live-bin-p9-72fd097" B_MMA=3 B_WINDOW_COLS=1
if [[ $leg == new2 ]]; then export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2; fi
export B_MIN_FREE_MIB=14000 B_GRID_TAIL="$kind-$leg"
while [[ ! -s "$name.done" ]]; do
    status=0
    perf/p11/b/gpu.sh bash -ec '
      name=$1 prior=$2 count=$3; shift 3
      [[ -s "$prior.done" ]] || exit 76
      date --iso-8601=ns >"$name.start"
      exec perf/p11/b/run.sh bench "$@"
    ' b-grid "$name" "$prior" "$count" "${args[@]}" -r 3 >"$name.json" 2>"$name.log" || status=$?
    if [[ $status == 76 ]]; then continue; fi
    if [[ $status != 0 ]]; then exit "$status"; fi
    python3 -c 'import json,sys; rows=json.load(open(sys.argv[1])); assert len(rows)==int(sys.argv[2]) and all(r["avg_ts"]>0 and len(r["samples_ts"])==3 for r in rows)' "$name.json" "$count"
    date --iso-8601=ns >"$name.done"
done
