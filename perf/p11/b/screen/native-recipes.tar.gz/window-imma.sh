set -euo pipefail
d=build/p11/window-imma
capture="$PWD/build/p11/window-capture-0"
model="$HOME/models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf"
mkdir -p "$d"
until [[ -s "$capture/7/down.output" ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
    sleep 15
done
for leg in old1 new1 new2 old2; do
    mma=3; if [[ $leg == new* ]]; then mma=1; fi
    exact=1; if [[ $leg == new* ]]; then exact=0; fi
    LD_LIBRARY_PATH="$HOME/inkling-live-bin-p9-72fd097" IK_MMA=$mma P11_REQUIRE_GRAPH_OUTPUT=$exact bash build/p11/window-projection.sh "$model" gate "$capture" "$d/verify-$leg-gate"
done
python3 perf/p11/b/screen/summarize_micro.py "$d" verify '' >perf/p11/b/screen/model-windows/p9-imma-vs-dp4a.tsv
