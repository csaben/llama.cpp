set -euo pipefail
d=build/p11/window-imma
capture="$PWD/build/p11/window-capture-0"
model="$HOME/models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf"
mkdir -p "$d"
until [[ -s "$capture/7/down.output" ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
    sleep 15
done
for leg in old1 new1 new2 old2; do
    mma=3; if [[ $leg == new* ]]; then mma=1; fi
    for width in 2 3 4 5 6 7; do
        a="$d/verify-$leg-gate-$width"
        if [[ -s "$a.tsv" ]]; then continue; fi
        B_MIN_FREE_MIB=1000 perf/p11/b/gpu.sh env LD_LIBRARY_PATH="$HOME/inkling-live-bin-p9-72fd097" P11_EXPERT_Q8=1 P11_STEADY=1 P11_EXPERT_INPUT_DIR="$capture/$width" IK_MMA=$mma IK_MR=1 GGML_CUDA_GRAPH_CHUNK_SIZE=0 build/p11/expert-q8 "$model" gate "$width" "$a.f32" >"$a.times" 2>"$a.log"
        if [[ $leg == old* ]]; then cmp "$a.f32" "$capture/$width/gate.output"; fi
        printf '%s\t%s\n' "$(cat "$a.times")" "$(sha256sum "$a.f32" | cut -d' ' -f1)" >"$a.tsv"
    done
done
python3 perf/p11/b/screen/summarize_micro.py "$d" verify '' >perf/p11/b/screen/model-windows/p9-imma-vs-dp4a.tsv
