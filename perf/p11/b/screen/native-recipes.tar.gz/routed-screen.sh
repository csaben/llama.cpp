set -euo pipefail
corpus=${1:?captured corpus name}
export P11_EXPERT_INPUT_DIR="$PWD/build/p11/capture-$corpus"
old="$HOME/inkling-live-bin-p9-72fd097"
raw=perf/p11/b/screen/micro
evidence="perf/p11/b/screen/routed-$corpus"
mkdir -p "$evidence"
cp "$P11_EXPERT_INPUT_DIR/out.txt" "$evidence/backends.txt"
(cd "$P11_EXPERT_INPUT_DIR" && sha256sum gate.{input,ids,output} down.{input,ids,output}) >"$evidence/capture.sha256"
python3 - "$P11_EXPERT_INPUT_DIR" >"$evidence/routes.txt" <<'PY'
import collections, struct, sys
from pathlib import Path
d=Path(sys.argv[1])
for proj in ('gate','down'):
    ids=struct.unpack('<4096i',(d/(proj+'.ids')).read_bytes())
    assert len(set(ids))<=128 and min(ids)>=0 and max(ids)<128 and all(len(set(ids[i:i+8]))==8 for i in range(0,len(ids),8))
    hist=collections.Counter(ids);cnt=sorted(hist[i] for i in range(128))
    print(proj,'active',sum(x>0 for x in cnt),'min',cnt[0],'median',(cnt[63]+cnt[64])/2,'p90',cnt[115],'max',cnt[-1])
    print('counts by expert',*(hist[i] for i in range(128)))
assert (d/'gate.ids').read_bytes()==(d/'down.ids').read_bytes()
PY
for suite in tile verify; do
    for leg in old1 new1 new2 old2; do
        lib=$old; mma=3
        if [[ $leg == new* ]]; then lib="$PWD/build/p11/combined-bin"; mma=7; fi
        B_MMA=$mma perf/p11/b/screen/micro.sh "$lib" "$suite" "routed-$corpus-$leg"
    done
    python3 perf/p11/b/screen/summarize_micro.py "$raw" "$suite" "routed-$corpus-" >"$evidence/$suite.tsv"
done
python3 - "$raw" "$evidence" "$corpus" <<'PY'
from pathlib import Path
import sys
d,e=map(Path,sys.argv[1:3]); name=sys.argv[3]
refs={item:sha for sha,item in (line.split() for line in (e/'capture.sha256').read_text().splitlines())}
out=e/'output-check.txt'
with out.open('w') as f:
    for op in ('gate','down'):
        for leg in ('old1','new1','new2','old2'):
            digest=(d/f'tile-routed-{name}-{leg}-{op}-512.tsv').read_text().split()[-1]
            print(op,leg,'model_output_match',digest==refs[op+'.output'],digest,file=f)
PY
