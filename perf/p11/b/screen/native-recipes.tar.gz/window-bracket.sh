set -euo pipefail
target="$HOME/models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf"
out=perf/p11/b/screen/model-windows
mkdir -p "$out"
for layer in 0 5 12; do
    capture="$PWD/build/p11/window-capture-$layer"
    until [[ -s "$capture/7/down.output" ]]; do
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
        sleep 15
    done
    cp "$capture/out.txt" "$out/layer-$layer-backends.txt"
    (cd "$capture" && sha256sum {2..7}/{gate,down}.{input,ids,output}) >"$out/layer-$layer.sha256"
    d="build/p11/window-paired-$layer"
    mkdir -p "$d"
    for leg in old1 new1 new2 old2; do
        lib="$HOME/inkling-live-bin-p9-72fd097"; mma=3
        if [[ $leg == new* ]]; then lib="$PWD/build/p11/narrow-bin"; mma=7; fi
        for proj in gate down; do
            LD_LIBRARY_PATH="$lib" P11_LAYER=$layer IK_MMA=$mma bash build/p11/window-projection.sh "$target" "$proj" "$capture" "$d/verify-$leg-$proj"
        done
    done
    python3 perf/p11/b/screen/summarize_micro.py "$d" verify '' >"$out/layer-$layer.tsv"
done
