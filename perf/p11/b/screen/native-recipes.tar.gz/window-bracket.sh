set -euo pipefail
target="$HOME/models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf"
out=perf/p11/b/screen/model-windows
mkdir -p "$out"
for layer in 0 5 12; do
    capture="$PWD/build/p11/window-capture-$layer"
    until [[ -s "$capture/7/down.output" ]]; do
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
        sleep 15
    done
    cp "$capture/out.txt" "$out/layer-$layer-backends.txt"
    (cd "$capture" && sha256sum {2..7}/{gate,down}.{input,ids,output}) >"$out/layer-$layer.sha256"
    d="build/p11/window-paired-$layer"
    mkdir -p "$d"
    for leg in old1 new1 new2 old2; do
        lib="$HOME/inkling-live-bin-p9-72fd097"; mma=3
        if [[ $leg == new* ]]; then lib="$PWD/build/p11/narrow-bin"; mma=7; fi
        for width in 2 3 4 5 6 7; do
            for proj in gate down; do
                a="$d/verify-$leg-$proj-$width"
                if [[ -s "$a.tsv" ]]; then continue; fi
                B_MIN_FREE_MIB=1000 perf/p11/b/gpu.sh env LD_LIBRARY_PATH="$lib" P11_LAYER=$layer P11_EXPERT_Q8=1 P11_STEADY=1 P11_EXPERT_INPUT_DIR="$capture/$width" IK_MMA=$mma IK_MR=1 GGML_CUDA_GRAPH_CHUNK_SIZE=0 \
                    build/p11/expert-q8 "$target" "$proj" "$width" "$a.f32" >"$a.times" 2>"$a.log"
                cmp "$a.f32" "$capture/$width/$proj.output"
                printf '%s\t%s\n' "$(cat "$a.times")" "$(sha256sum "$a.f32" | cut -d' ' -f1)" >"$a.tsv"
            done
        done
    done
    python3 perf/p11/b/screen/summarize_micro.py "$d" verify '' >"$out/layer-$layer.tsv"
done
