set -euo pipefail
B_OPERATOR_SWEEP=1 B_MIN_FREE_MIB=1200 python3 perf/p11/b/configure.py >build/p11/final-configure.log 2>&1
python3 perf/p11/b/cache_audit.py >perf/p11/b/baseline/full-cache.txt
nice -n 15 cmake --build build -j4 --target llama-server llama-bench llama-perplexity test-backend-ops >build/p11/final-four-targets.log 2>&1
rg 'Built target (llama-server|llama-bench|llama-perplexity|test-backend-ops)$' build/p11/final-four-targets.log >perf/p11/b/baseline/final-build.txt
test "$(wc -l <perf/p11/b/baseline/final-build.txt)" -eq 4
