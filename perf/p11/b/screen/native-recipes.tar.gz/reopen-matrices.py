from datetime import datetime
from pathlib import Path
import time
root=Path('build/p11/supervisor')
while datetime.now().strftime('%H%M')<'0730' and not Path('perf/STOP').exists() and not (Path.home()/'llama.cpp-fast/perf/STOP').exists():
 for f in root.glob('matrix-*.status'):
  code=int(f.read_text().split()[-1])
  if code != 127:continue
  dest=f.with_suffix('.reopened-127')
  log=f.with_suffix('.log').read_text()
  if not dest.exists() and 'v: command not found' in log:
   f.rename(dest);print('Rechecking preserved matrix with current shell script:',f.stem,flush=True)
 time.sleep(10)
