set -euo pipefail
s=build/p11
d=perf/p11/b/screen
gpu=(perf/p11/b/gpu.sh perf/p11/b/run.sh)
bench() {
    local target=$1;shift
    if ! python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))[0]["avg_ts"]>0' "$target" 2>/dev/null; then
        "${gpu[@]}" bench "$@" >"$target" 2>"$s/screen/retry-$(basename "$target").log"
    fi
}
case ${1:?} in
    prefill)
        for ub in 640 768 1024 1536 2048; do
            for depth in 4096 16384; do B_UBATCH=$ub bench "$d/ubatch/pp$depth-ub$ub.json" -p "$depth" -n 0 -r 2; done
        done
        for j in 40 48 64 80 96; do
            P11B_Q2K_J=$j B_LIBS="$PWD/$s/screen-bin" bench "$d/pp-q2k-j$j.json" -p 4096 -n 0 -r 2
            P11B_Q20_J=$j B_LIBS="$PWD/$s/screen-bin" bench "$d/pp-q20-j$j.json" -p 4096 -n 0 -r 2
        done
        export B_LIBS="$PWD/$s/screen-bin"
        P11B_TILE_MIN=101 bench "$d/pp-stream-all.json" -p 4096 -n 0 -r 2
        for w in 1 2 4 8; do P11B_TILE_MIN=101 P11B_STREAM_WAVES=$w bench "$d/pp-stream-waves$w.json" -p 4096 -n 0 -r 2; done
        bench "$d/pp-base1.json" -p 4096 -n 0 -r 2
        for name in geom-i32-t64-o4 geom-i128-t256-o2 geom-i128-t256-o3 bias-bin; do
            label=$name; if [[ $name == bias-bin ]]; then label=bias-bin-repeat; fi
            B_LIBS="$PWD/$s/$name" bench "$d/geometry/$label.json" -p 4096 -n 0 -r 3
        done
        for leg in old1 new1 new2 old2; do
            lib=verify-bin; if [[ $leg == new* ]]; then lib=fa-bin; fi
            B_LIBS="$PWD/$s/$lib" bench "$d/fa/65536-$leg.json" -p 65536 -n 0 -r 1
            lib=bias-bin; if [[ $leg == new* ]]; then lib=id-bin; fi
            B_LIBS="$PWD/$s/$lib" bench "$d/id-$leg.json" -p 4096 -n 0 -r 3
        done ;;
    attention)
        MR_RS_A=0 MR_RS=6 MR_SIZES=2,3,4,5,6,7 MR_ROLLBACK=0 MR_CTX=8192 "${gpu[@]}" mr perf/ppl.txt 200 144 >"$s/screen/verify-old2.log" 2>&1
        rg 'single token:|window of |rows differ' "$s/screen/verify-old2.log" >"$d/verify/old2.txt"
        for depth in 200 16384; do
            for v in base occupancy6 occupancy14 longer_steps external_single external_window packed_wide window_tile no_pack base_repeat; do
                out="$d/attention/$depth-$v.txt"
                if [[ -s $out ]]; then continue; fi
                opts=()
                case $v in
                    occupancy6) opts=(IK_ATTN_MMA_SPLITS=6) ;;
                    occupancy14) opts=(IK_ATTN_MMA_SPLITS=14) ;;
                    longer_steps) opts=(IK_ATTN_MMA_SPW=2) ;;
                    external_single) opts=(IK_ATTN_SCAN_MIN=2048 MR_SIZES=1) ;;
                    external_window) opts=(IK_WINDOW_SCAN_MIN=2048 B_WINDOW_COLS=0) ;;
                    packed_wide) opts=(B_WINDOW_COLS=2) ;;
                    window_tile) opts=(IK_WINDOW_TILE_ROWS=4 B_WINDOW_COLS=0) ;;
                    no_pack) opts=(B_WINDOW_COLS=0) ;;
                esac
                log="$s/screen/attn-$depth-$v.log"
                env MR_SIZES=2,3,4,5,6,7 "${opts[@]}" MR_RS_A=0 MR_RS=6 MR_ROLLBACK=0 MR_CTX=20500 "${gpu[@]}" mr perf/ppl.txt "$depth" 72 >"$log" 2>&1 || rg -q 'rows differ from single-token decode' "$log"
                rg 'rows differ|single token:|window of ' "$log" >"$out"
            done
        done
        bash "$s/probe-logits.sh" >"$d/prefill-logits.sha256"
        sed -n '/^export B_LIBS=/,$p' "$s/controller-screen.sh" | bash -eu -o pipefail ;;
    served)
        for leg in old1 new1 new2 old2; do
            cap=6; if [[ $leg == new* ]]; then cap=7; fi
            B_LIBS="$PWD/$s/history-bin" "${gpu[@]}" probe "$s/history-screen/3000" "$leg" "$cap" code,edit,prose,agent 1 3000
            if [[ $leg != old1 ]]; then SPEC_KINDS=code,edit,prose,agent SPEC_REQUIRE_IDS=1 python3 perf/p6/r4_cmp.py "$s/history-screen/3000" old1 "$leg" >"$s/history-screen/3000/$leg.equal"; fi
        done
        B_LIBS="$PWD/$s/policy-bin" P11B_MODEL_CAP=3 P11B_VERIFY_SCALE=1.15 "${gpu[@]}" probe "$s/policy-screen/384" w3-s1.15 6 code,edit,prose,agent 2 384
        B_LIBS="$PWD/$s/history-bin" P11B_VERIFY_SCALE=1.0 "${gpu[@]}" probe "$s/policy-low/384" n6-1.0 6 code,edit,prose,agent,letter,scene 3 384
        for v in 1 3; do
            MR_RS_A=0 MR_RS=6 MR_ROLLBACK=0 MR_CTX=20500 MR_SIZES=2,3,4,5,6,7 B_MMA=$v "${gpu[@]}" mr perf/ppl.txt 16384 72 >"$s/screen/attn-mma$v.log" 2>&1 || rg -q 'rows differ' "$s/screen/attn-mma$v.log"
            rg 'rows differ|single token:|window of ' "$s/screen/attn-mma$v.log" >"$d/attention/mma$v.txt"
        done ;;
    *) exit 2 ;;
esac
date --iso-8601=seconds >"$s/finish-screens-$1.done"
