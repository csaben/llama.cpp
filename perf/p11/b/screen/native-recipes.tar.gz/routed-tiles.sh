set -eu
for name in ppl code prose; do
    d="$PWD/build/p11/capture-$name"
    until [[ -s "perf/p11/b/screen/routed-$name/capture.sha256" ]]; do
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
        sleep 15
    done
    (cd "$d" && sha256sum -c "$OLDPWD/perf/p11/b/screen/routed-$name/capture.sha256")
    for j in 8 16 24 32 40 48 64 80 96; do
        P11_EXPERT_INPUT_DIR="$d" P11B_Q2K_J=$j P11B_Q20_J=$j perf/p11/b/screen/micro.sh "$PWD/build/p11/screen-bin" tile "prompt-$name-j$j"
    done
done
