set -euo pipefail
until [[ -s build/p11/combined-bin.sha256 ]]; do sleep 5; done
for suite in tile verify; do
    for leg in old1 new1 new2 old2; do
        lib="$HOME/inkling-live-bin-p9-72fd097"; mma=3
        if [[ $leg == new* ]]; then lib="$PWD/build/p11/combined-bin"; mma=7; fi
        B_MMA=$mma perf/p11/b/screen/micro.sh "$lib" "$suite" "combined-$leg"
    done
    python3 perf/p11/b/screen/summarize_micro.py perf/p11/b/screen/micro "$suite" combined- >"perf/p11/b/screen/combined-$suite.tsv"
done
