from pathlib import Path
from datetime import datetime
import csv,hashlib,io,json,re,subprocess,tarfile
base=Path('perf/p11/b')
scr=base/'screen'
out=scr/'recovery'
floor=datetime.fromisoformat('2026-11-27T03:30:22-05:00').timestamp()
requirements=list(csv.DictReader((out/'allocation-failures.tsv').open(),delimiter='\t'))
spec=[
 ('preflight-logits/bias-bin.log','hash',out/'bias-logits.sha256'),
 ('screen/ub640-4096.log','bench',scr/'ubatch/pp4096-ub640.json'),
 ('screen/q2k-j40.log','bench',out/'q2k-j40.json'),
 ('screen/geom-i32-t64-o4.log','bench',out/'geom-i32-t64-o4.json'),
 ('screen/id-new2.log','bench',out/'id-new2.json'),
 ('screen/attn-200-no_pack.log','rows',out/'no-pack.txt'),
 ('screen/ctrl0.log','bench',out/'ctrl0.json'),
 ('screen/fa-65536-new1.log','bench',out/'fa-65536-new1.json'),
 ('policy-screen/384/w3-s1.15.server.log','serve',Path('build/p11/oom-audit/w3-s1.15.txt')),
 ('policy-bracket/short384/new2.server.log','serve',Path('build/p11/policy-bracket-native/short384/new2.txt')),
 ('policy-low/384/n6-1.0.server.log','serve',Path('build/p11/oom-audit/n6-1.0.txt'))]
assert {r['original_log'] for r in requirements}=={s[0] for s in spec}
files={}
table=io.StringIO()
w=csv.writer(table,delimiter='\t',lineterminator='\n')
w.writerow(('original_allocation_failure','native_state','evidence_member','file_sha256'))
for orig,kind,p in spec:
 if orig=='screen/attn-200-no_pack.log' and not p.is_file():
  p=scr/'attention/200-no_pack.txt'
 if not p.is_file() or not p.stat().st_size or p.stat().st_mtime<floor:
  w.writerow((orig,'pending','-','-'));continue
 data=p.read_bytes()
 if kind=='hash':
  digest,name=p.read_text().split()
  assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
 elif kind=='bench':
  try:r,=json.loads(data)
  except (ValueError,TypeError):w.writerow((orig,'pending','-','-'));continue
  assert r['avg_ts']>0 and all(v>0 for v in r['samples_ts'])
 elif kind=='rows':
  assert re.search(r'0 rows differ from single-token decode, max \|logit diff\| 0$',p.read_text(),re.M)
 else:
  prompts='code,edit,prose,agent,letter,scene' if p.stem=='n6-1.0' else 'code,edit,prose,agent'
  reps=2 if p.stem=='w3-s1.15' else 3
  if subprocess.run(['python3',str(base/'probe_complete.py'),str(p.parent),p.stem,prompts,str(reps),'384']).returncode:
   w.writerow((orig,'pending','-','-'));continue
  for prompt in prompts.split(','):
   suite='prose' if prompt in ('letter','scene') else 'main'
   for ext in ('json','ids'):
    result=p.with_name(f'{p.stem}.{prompt}.{ext}')
    plain=Path('build/p11/matrix-p9') / suite / '384'/f'plain.{prompt}.{ext}'
    assert result.read_bytes()==plain.read_bytes()
    files[f'{p.stem}/{result.name}']=result.read_bytes()
 n=p.name;files[n]=data
 w.writerow((orig,'completed',n,hashlib.sha256(data).hexdigest()))
dest=out/'native-retries.tsv';dest.write_text(table.getvalue())
files[dest.name]=dest.read_bytes()
archive=out/'native-retries.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,data in sorted(files.items()):
  info=tarfile.TarInfo(n);info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:
 assert all(t.extractfile(n).read()==v for n,v in files.items())
print(table.getvalue(),end='')
