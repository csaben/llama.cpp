set -euo pipefail
export P11_STEADY=1
for name in uniform ppl code prose layer5 layer12; do
    if [[ $name != uniform ]]; then
        export P11_EXPERT_INPUT_DIR="$PWD/build/p11/capture-$name"
        until [[ -s "perf/p11/b/screen/routed-$name/capture.sha256" ]]; do
            [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
            sleep 10
        done
    fi
    export P11_LAYER=0
    if [[ $name == layer* ]]; then P11_LAYER=${name#layer}; fi
    for leg in old1 new1 new2 old2; do
        lib="$HOME/inkling-live-bin-p9-72fd097"; mma=3
        if [[ $leg == new* ]]; then lib="$PWD/build/p11/combined-bin"; mma=7; fi
        B_MMA=$mma perf/p11/b/screen/micro.sh "$lib" tile "steady-$name-$leg"
    done
    python3 perf/p11/b/screen/summarize_micro.py perf/p11/b/screen/micro tile "steady-$name-" >"perf/p11/b/screen/steady-$name.tsv"
done
