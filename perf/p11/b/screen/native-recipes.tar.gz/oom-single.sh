set -euo pipefail
gpu=(perf/p11/b/gpu.sh perf/p11/b/run.sh)
d="build/p11/oom-independent-$B_RECOVERY_CASE"
mkdir -p "$d"
e=perf/p11/b/screen/recovery
bench() {
    local label=$1 lib=$2 depth=$3 count=$4
    if [[ $label != "$B_RECOVERY_CASE" ]]; then return; fi
    if [[ -s "$e/$label.json" ]]; then return; fi
    B_LIBS="$lib" "${gpu[@]}" bench -p "$depth" -n 0 -r "$count" >"$d/$label.json" 2>"$d/$label.log"
    python3 - "$d/$label.json" "$depth" "$count" <<'PY'
import sys,json
r,=json.load(open(sys.argv[1]))
assert r['avg_ts']>0 and r['n_prompt']==int(sys.argv[2]) and len(r['samples_ts'])==int(sys.argv[3])
PY
    cp "$d/$label.json" "$e/$label.json"
}
case "$1" in
    prefill)
        test -s perf/p11/b/screen/ubatch/pp4096-ub640.json
        python3 -c 'import json; x,=json.load(open("perf/p11/b/screen/ubatch/pp4096-ub640.json"));assert (x["n_prompt"],x["n_ubatch"],len(x["samples_ts"]))==(4096,640,2)'
        P11B_Q2K_J=40 bench q2k-j40 "$PWD/build/p11/screen-bin" 4096 2
        bench geom-i32-t64-o4 "$PWD/build/p11/geom-i32-t64-o4" 4096 3
        bench id-new2 "$PWD/build/p11/id-bin" 4096 3
        P11B_CTRL_MATH=0 bench ctrl0 "$PWD/build/p11/ctrl-bin" 4096 3
        bench fa-65536-new1 "$PWD/build/p11/fa-bin" 65536 1 ;;
    numerics)
        if [[ $B_RECOVERY_CASE == bias ]]; then
        B_LIBS="$PWD/build/p11/bias-bin" "${gpu[@]}" logits 4096 2 >"$d/bias.f32" 2>"$d/bias.log"
        test "$(stat -c%s "$d/bias.f32")" = 1600464
        cmp "$d/bias.f32" build/p11/preflight-logits/p9.f32
        sha256sum "$d/bias.f32" >"$e/bias-logits.sha256"
        else
        MR_RS_A=0 MR_RS=6 MR_SIZES=2,3,4,5,6,7 MR_ROLLBACK=0 MR_CTX=20500 B_WINDOW_COLS=0 "${gpu[@]}" mr perf/ppl.txt 200 72 >"$d/no-pack.log" 2>&1
        rg 'single token:|window of |rows differ from' "$d/no-pack.log" >"$e/no-pack.txt"
        rg -q '0 rows differ from single-token decode, max \|logit diff\| 0$' "$e/no-pack.txt"
        fi ;;
    policy)
        for label in w3-s1.15 n6-1.0; do
            lib=history-bin; scale=1.0; reps=3; kinds=code,edit,prose,agent,letter,scene
            if [[ $label == w3-s1.15 ]]; then lib=policy-bin; scale=1.15; reps=2; kinds=code,edit,prose,agent; fi
            B_LIBS="$PWD/build/p11/$lib" P11B_MODEL_CAP=3 P11B_VERIFY_SCALE="$scale" "${gpu[@]}" probe "$d" "$label" 6 "$kinds" "$reps" 384
            python3 perf/p11/b/probe_complete.py "$d" "$label" "$kinds" "$reps" 384
            for prompt in ${kinds//,/ }; do
                suite=main
                if [[ $prompt == letter || $prompt == scene ]]; then suite=prose; fi
                for ext in ids json; do cmp "$d/$label.$prompt.$ext" "build/p11/matrix-p9/$suite/384/plain.$prompt.$ext"; done
            done
            cp "$d/$label.txt" "$e/$label.txt"
        done ;;
esac
date --iso-8601=seconds >"$d/$1.done"
