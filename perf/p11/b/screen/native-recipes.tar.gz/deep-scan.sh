set -euo pipefail
d=build/p11/deep-scan
mkdir -p "$d"
out=perf/p11/b/screen
for leg in old1 new1 new2 old2; do
    cols=1; if [[ $leg == new* ]]; then cols=2; fi
    for depth in 4096 65536 127872; do
        for width in 4 5 6 7; do
            a="$d/packed-$leg-$depth-$width"
            if [[ -s "$a.tsv" ]]; then continue; fi
            B_MIN_FREE_MIB=1200 perf/p11/b/gpu.sh env LD_LIBRARY_PATH="$HOME/inkling-live-bin-p9-72fd097" P11_STEADY=1 IK_MMA=3 IK_MR=1 IK_WINDOW_COLS=$cols GGML_CUDA_GRAPH_CHUNK_SIZE=0 build/p11/attention-steady "$depth" "$width" "$a.attn" >"$a.times" 2>"$a.log"
            printf '%s\t%s\n' "$(cat "$a.times")" "$(sha256sum "$a.attn" | cut -d' ' -f1)" >"$a.tsv"
        done
    done
done
python3 - "$d" "$out" <<'PY'
from pathlib import Path
from statistics import mean,median
import csv,sys
d,out=map(Path,sys.argv[1:])
with (out/'deep-packed.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n')
 w.writerow(('depth','width','old1_us','new1_us','new2_us','old2_us','old_mean_us','new_mean_us','delta_pct','output_sha256'))
 for depth in (4096,65536,127872):
  for width in (4,5,6,7):
   rows=[(d/f'packed-{l}-{depth}-{width}.tsv').read_text().split() for l in ('old1','new1','new2','old2')]
   assert len({r[-1] for r in rows})==1 and all(len(r)==12 for r in rows)
   times=[median(map(float,r[2:-1])) for r in rows]
   old,new=mean((times[0],times[3])),mean(times[1:3])
   w.writerow([depth,width,*times,round(old,3),round(new,3),round(100*(new/old-1),2),rows[0][-1]])
PY
