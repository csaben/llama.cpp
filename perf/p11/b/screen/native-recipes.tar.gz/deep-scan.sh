set -euo pipefail
d=build/p11/deep-scan
mkdir -p "$d"
out=perf/p11/b/screen
for leg in old1 new1 new2 old2; do
    cols=1; if [[ $leg == new* ]]; then cols=2; fi
    B_SCAN_RAW="$d" B_SCAN_WORK="$d" B_SCAN_LENGTHS='4096 65536 127872' B_SCAN_WIDTHS='4 5 6 7' P11_STEADY=1 IK_WINDOW_COLS=$cols perf/p11/b/screen/scan.sh "packed-$leg"
done
python3 - "$d" "$out" <<'PY'
from pathlib import Path
from statistics import mean,median
import csv,sys
d,out=map(Path,sys.argv[1:])
with (out/'deep-packed.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n')
 w.writerow(('depth','width','old1_us','new1_us','new2_us','old2_us','old_mean_us','new_mean_us','delta_pct','output_sha256'))
 for depth in (4096,65536,127872):
  for width in (4,5,6,7):
   rows=[(d/f'packed-{l}-{depth}-{width}.tsv').read_text().split() for l in ('old1','new1','new2','old2')]
   assert len({r[-1] for r in rows})==1 and all(len(r)==12 for r in rows)
   times=[median(map(float,r[2:-1])) for r in rows]
   old,new=mean((times[0],times[3])),mean(times[1:3])
   w.writerow([depth,width,*times,round(old,3),round(new,3),round(100*(new/old-1),2),rows[0][-1]])
PY
