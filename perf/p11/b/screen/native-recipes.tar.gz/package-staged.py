from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
name=sys.argv[1]
directories={'p9':('staged-fallback',Path.home()/'inkling-live-bin-p11b-72fd097'), 'candidate':('staged-narrow-candidate',Path('build/p11/independent-narrow').resolve()),'release':('staged-narrow',Path.home()/'inkling-live-bin-p11b-caec8de6')}
tag,snapshot=directories[name]
d=Path('build/p11')/tag
root=Path('perf/p11/b')
out=root/'staged-controls'
out.mkdir(exist_ok=True)
expected=(root/'narrow/runtime.sha256' if name!='p9' else Path('perf/p9/snapshot.sha256')).read_text().splitlines()
files={}
manifest=[]
for line in expected:
 sha,rawname=line.split()
 fn=Path(rawname).name
 with (snapshot/fn).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==sha
 manifest.append(f'{sha}  {fn}\n')
files['runtime.sha256']=''.join(manifest).encode()
prompts=['code','edit','prose','agent']
legs=[]
for leg in ['plain-before','draft1','draft2','plain-after']:
 if subprocess.run([sys.executable,str(root/'probe_complete.py'),str(d),leg,','.join(prompts),'3','384']).returncode:continue
 lines=(d/(leg+'.txt')).read_text().splitlines()
 files[leg+'.txt']=('\n'.join(lines)+'\n').encode()
 for prompt in prompts:
  for ext in ['ids','json']:
   fn=f'{leg}.{prompt}.{ext}'
   ref=f'plain.{prompt}.{ext}'
   answer=(d/fn).read_bytes()
   assert answer==(d/f'plain-before.{prompt}.{ext}').read_bytes()==(Path('build/p11/matrix-p9/main/384')/ref).read_bytes()
   if ext=='ids':assert len(answer)==384*4
   else:assert any(json.loads(answer).get(k) for k in ('content','reasoning_content','tool_calls'))
   files[fn]=answer;files['p9-'+ref]=answer
 legs.append(leg)
if legs:
 n=sum(12 for l in legs if l.startswith('draft'))
 text=f'{len(legs)}/4 vision-server processes audited on GPU0 port 18550, snapshot {snapshot.name}. Completed '+', '.join(legs)+f'. {n} drafted replies, {n*384:,} generated IDs. Complete messages and IDs matched frozen p9 and each available plain control. All nine runtime hashes matched.\n'
 files['audit.txt']=text.encode()
 archive=out/(name+'.tar.gz')
 with tarfile.open(archive,'w:gz') as t:
  for key,data in sorted(files.items()):
   info=tarfile.TarInfo(key);info.size=len(data);t.addfile(info,io.BytesIO(data))
 with tarfile.open(archive) as t:
  assert all(t.extractfile(k).read()==v for k,v in files.items())
 (out/(name+'.txt')).write_text(text);print(text,end='')
