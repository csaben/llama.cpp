set -euo pipefail
bin="$HOME/opt/cuda-12.8/bin/compute-sanitizer"
lib="$PWD/build/p11/narrow-bin"
mkdir -p perf/p11/b/screen/ops/narrow
for mode in memcheck synccheck; do
    log="build/p11/ops/narrow-$mode"
    B_MIN_FREE_MIB=1300 perf/p11/b/gpu.sh timeout -k 5 160 env LD_LIBRARY_PATH="$lib" IK_MR=1 IK_MMA=7 "$bin" --tool "$mode" --error-exitcode 86 \
        --log-file "$log.sanitizer" build/bin/test-backend-ops test -b CUDA0 --test-file perf/p11/b/screen/window.ops -p 'name=gate-[567],' >"$log.ops" 2>&1
    out="perf/p11/b/screen/ops/narrow/$mode.txt"
    { rg ' 3/3 tests passed' "$log.ops"; rg 'ERROR SUMMARY: 0 errors' "$log.sanitizer"; } >"$out"
done
