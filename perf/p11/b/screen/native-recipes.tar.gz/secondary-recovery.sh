set -euo pipefail
d=perf/p11/b
for depth in 16384 32768 65536; do
    B_PLAIN=1 "$d/gpu.sh" "$d/run.sh" bench -p 0 -n 128 -d "$depth" -r 3 >"$d/baseline/plain/tg-$depth.json" 2>"build/p11/p9-plain-$depth.log"
done
bash build/p11/iq4-baseline.sh
