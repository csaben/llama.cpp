set -euo pipefail
d=perf/p11/b/baseline
for type in prefill decode; do
    opts=(-c 2048 -b 2048 -ub 512 --chunks 8)
    if [[ $type == decode ]]; then opts=(-c 1024 -b 1024 -ub 1 --chunks 2); fi
    B_MMA=0 B_MR=0 perf/p11/b/gpu.sh perf/p11/b/run.sh ppl "${opts[@]}" >"build/p11/$type-default.log" 2>&1
    rg 'Final estimate' "build/p11/$type-default.log" >"$d/$type-default.txt"
done
