set -euo pipefail
export B_MODEL="$HOME/models/inkling-2-mini/Inkling-2-Mini-IQ4_NL-dense-iq4nl.gguf" B_CTX=65536
d=build/p11/iq4-short
e=perf/p11/b/iq4-p9
mkdir -p "$d" "$e"
for depth in 0 4096; do
    perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p 0 -n 128 -d "$depth" -r 3 >"$d/tg-$depth.json" 2>"$d/tg-$depth.log"
    python3 - "$d/tg-$depth.json" "$depth" <<'PY'
import json,sys
x,=json.load(open(sys.argv[1]))
assert x['n_depth']==int(sys.argv[2]) and x['n_gen']==128 and len(x['samples_ts'])==3 and x['avg_ts']>0
PY
    cp "$d/tg-$depth.json" "$e/native-tg-$depth.json"
done
for leg in plain-p9 old1 new1 new2 old2 plain-new; do
    export B_LIBS="$HOME/inkling-live-bin-p9-72fd097" B_MMA=3 B_WINDOW_COLS=1 LLAMA_DSPARK_FULL_RATE=0
    if [[ $leg == new* || $leg == plain-new ]]; then
        B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1
    fi
    cap=6
    if [[ $leg == plain-* ]]; then cap=0; fi
    perf/p11/b/gpu.sh perf/p11/b/run.sh probe "$d" "$leg" "$cap" edit 3 384
    python3 perf/p11/b/probe_complete.py "$d" "$leg" edit 3 384
    for ext in json ids; do cmp "$d/$leg.edit.$ext" "$d/plain-p9.edit.$ext"; done
done
python3 - "$d" "$e" <<'PY'
from pathlib import Path
from statistics import mean
import hashlib,sys,tarfile
d,e=map(Path,sys.argv[1:])
legs=('old1','new1','new2','old2')
rates=[float((d/(l+'.txt')).read_text().split()[6]) for l in legs];old=mean((rates[0],rates[3]));new=mean(rates[1:3])
digest=hashlib.sha256((d/'plain-p9.edit.ids').read_bytes()).hexdigest()
(e/'edit-384.tsv').write_text('old1\tnew1\tnew2\told2\told_mean\tnew_mean\tdelta_pct\tids_sha256\n'+'\t'.join([*(f'{v:.3f}' for v in (*rates,old,new,100*(new/old-1))),digest])+'\n')
with tarfile.open(e/'edit-384-captures.tar.gz','w:gz') as t:
 for leg in ('plain-p9',*legs,'plain-new'):
  for suffix in ('.txt','.edit.ids','.edit.json'):
   p=d/(leg+suffix);t.add(p,arcname=p.name,recursive=False)
PY
