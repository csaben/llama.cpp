from pathlib import Path
import csv,hashlib,sys
import numpy as np

w=Path('build/p11/narrow-checks')
out=Path('perf/p11/b/narrow/logits')
partial='--partial' in sys.argv
rows=[]
for depth in (200,4096,16384,32768,65536):
    proof=out/f'{depth}.sha256'
    if not proof.exists():
        if partial: continue
        raise FileNotFoundError(proof)
    digests=[line.split()[0] for line in proof.read_text().splitlines()]
    assert len(digests)==2 and digests[0]==digests[1]
    root=w/f'logits-{depth}'
    data=[(root/(name+'.f32')).read_bytes() for name in ('p9','new')]
    assert data[0]==data[1] and hashlib.sha256(data[0]).hexdigest()==digests[0]
    values=np.frombuffer(data[0],'<f4').reshape(8,200058)
    assert np.isfinite(values).all()
    for index,row in enumerate(values):
        rows.append((depth,index+1,len(row),float(row.min()),float(row.max()),hashlib.sha256(row).hexdigest()))
if rows:
    with (out/'rows.tsv').open('w') as f:
        writer=csv.writer(f,delimiter='\t',lineterminator='\n')
        writer.writerow(('prefix','row','finite_fp32_logits','min','max','matching_p9_new_sha256'))
        writer.writerows(rows)
print(len(rows),'full-vocabulary rows read, all finite and byte-identical')
