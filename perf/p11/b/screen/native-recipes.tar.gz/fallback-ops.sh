set -eu
export B_LIBS="$HOME/inkling-live-bin-p11b-72fd097" B_MIN_FREE_MIB=1000
out=perf/p11/b/baseline/staged-ops
mkdir -p "$out"
for spec in MUL_MAT_ID,'m=257,n=512,k=512' FLASH_ATTN_EXT,'rel_bias=1' INKLING_ATTN,'type_kv=q8_0'; do
 op=${spec%%,*}; filter=${spec#*,}
 log="build/p11/ops/staged-$op.log"
 perf/p11/b/gpu.sh perf/p11/b/run.sh ops -o "$op" -p "$filter" >"$log" 2>&1
 sed -E 's/\x1B\[[0-9;]*[mK]//g' "$log" | rg 'tests passed|Backend CUDA0:|FAIL' >"$out/$op.txt"
done
