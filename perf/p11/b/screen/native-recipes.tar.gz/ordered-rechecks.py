from pathlib import Path
import time
from datetime import datetime
work=Path('build/p11/supervisor')
sets=[
 (['bracket-new2-pp','bracket-new2-tg','primary-decode-0-old1'],['bracket-old2-pp','bracket-old2-tg','primary-decode-1-new1']),
 (['primary-decode-1-new1'],['primary-decode-2-new2']),
 (['primary-decode-2-new2'],['primary-decode-3-old2'])]
for previous,following in sets:
 while True:
  if datetime.now().strftime('%H%M')>='0730' or Path('perf/STOP').exists() or (Path.home()/'llama.cpp-fast/perf/STOP').exists():raise SystemExit(75)
  log=Path('build/p11/supervisor.log').read_text().splitlines()
  if all(any(x.split()[1:3]==[key,'started'] and 'T06:4' in x for x in log) for key in previous):break
  time.sleep(2)
 time.sleep(2)
 for key in following:
  status=work/(key+'.status')
  if status.exists() and status.read_text().split()[-1]=='143':status.rename(status.with_suffix('.original-slot'))
