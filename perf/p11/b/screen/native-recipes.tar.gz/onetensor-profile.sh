set -euo pipefail
nsys="$HOME/opt/cuda-12.8/nsight-systems-2024.6.2/bin/nsys"
for config in p9-down-512 combined-down-512 p9-gate-7 narrow-gate-7; do
    IFS=- read -r version projection columns <<<"$config"
    lib="$PWD/build/p11/$version-bin"; mma=7
    if [[ $version == p9 ]]; then lib="$HOME/inkling-live-bin-p9-72fd097"; mma=3; fi
    base="$PWD/build/p11/profiles/op-$config"
    LD_LIBRARY_PATH="$lib" P11_EXPERT_INPUT_DIR="$PWD/build/p11/capture-ppl" IK_MR=1 IK_MMA=$mma GGML_CUDA_GRAPH_CHUNK_SIZE=0 B_MIN_FREE_MIB=1300 perf/p11/b/gpu.sh "$nsys" profile --sample=none --cpuctxsw=none -t cuda --cuda-graph-trace=node --force-overwrite=true -o "$base" \
        "$PWD/build/p11/expert" \
        "$HOME/models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf" "$projection" "$columns" "$base.f32" >"$base.log" 2>&1 || test -s "$base.qdstrm"
    if [[ ! -s $base.nsys-rep ]]; then
        env -u LD_PRELOAD "$(dirname "$nsys")/../host-linux-x64/QdstrmImporter" -i "$base.qdstrm" -o "$base.nsys-rep" >>"$base.log" 2>&1
    fi
    env -u LD_PRELOAD "$nsys" stats --force-export=true --report cuda_gpu_kern_sum --force-overwrite=true --format csv -o "$base" "$base.nsys-rep" >>"$base.log" 2>&1
    cp "${base}_cuda_gpu_kern_sum.csv" "perf/p11/b/screen/nsys-$config.csv"
done
