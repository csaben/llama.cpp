import json
from pathlib import Path
d=Path('build/p11/capture-inputs')
d.mkdir(exist_ok=True)
prompt='Rewrite the following Python code so that every function and variable has type hints and the HTTP calls go through one helper function. Output the complete file, changing nothing else.\n'
(d/'edit.txt').write_text(prompt+Path('perf/bench.py').read_text()+Path('perf/kernsum.py').read_text())
msg=json.loads(Path('perf/p11/b/baseline/short/n0.prose.json').read_text())
(d/'story.txt').write_text((msg.get('reasoning_content') or msg['content'])+'\n')
