set -euo pipefail
depth=$1
dest="perf/p11/b/narrow/checks/rollback-$depth.log"
test='126 rows .*: 0 rows differ from single-token decode, max \|logit diff\| 0$'
if rg -q "$test" "$dest" 2>/dev/null; then exit 0; fi
export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1 B_ROLLBACK_DEPTH=$depth
export MR_RS_A=0 MR_RS=4 MR_RAND=37 MR_SIZES=2,3,4,5 MR_PLAIN_PCT=15 MR_PLAIN_RUN=8 B_MIN_FREE_MIB=11500
log="build/p11/primary-rollback-$depth.log"
perf/p11/b/gpu.sh bash -ec '
 if rg -q "$1" "$2" 2>/dev/null; then cat "$2"; else exec perf/p11/b/run.sh mr perf/ppl.txt "$3" 64; fi
' b-rollback "$test" "$dest" "$depth" >"$log" 2>&1
rg -q "$test" "$log"
if ! rg -q "$test" "$dest" 2>/dev/null; then cp "$log" "$dest.primary"; mv "$dest.primary" "$dest"; fi
