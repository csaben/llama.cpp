"""Replay the recorded shapes for one expert kernel configuration per GPU process."""
from pathlib import Path
import csv,datetime,fcntl,hashlib,os,subprocess,sys,tempfile,time

w=Path('build/p11')
out=Path('perf/p11/b/screen/micro')
saved=w/'occupied/screen/micro'
replay=w/'native-expert-replays'
replay.mkdir(exist_ok=True)
old=Path.home()/'inkling-live-bin-p9-72fd097'
model=Path.home()/'models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf'
family=sys.argv[1]
family_lock=(replay/(family+".lock")).open("w")
fcntl.flock(family_lock,fcntl.LOCK_EX)

def wait_capture(dataset):
    if dataset=='uniform':return
    f=w/f'capture-{dataset}'/'fresh.sha256'
    while not f.is_file() or not f.stat().st_size:
        if Path('perf/STOP').exists() or (Path.home()/'llama.cpp-fast/perf/STOP').exists() or datetime.datetime.now().strftime('%H%M')>='0730':
            sys.exit(75)
        time.sleep(10)

def cases(suite, label, dataset):
    result=[]
    for n in ([512] if suite=='tile' else list(range(2,8))):
        for proj in ('gate','down'):
            name=f'{suite}-{label}-{proj}-{n}'
            if (saved/(name+'.tsv')).is_file():
                result.append((name,proj,n,dataset))
    return result

def run(tag,lib,env,items):
    todo=[row for row in items if not (replay/(row[0]+'.tsv')).is_file()]
    if not todo:return
    for dataset in sorted({x[-1] for x in todo}):wait_capture(dataset)
    with tempfile.TemporaryDirectory(dir=w,prefix='expert-sweep-') as tmp:
        scratch=Path(tmp)
        command=['perf/p11/b/gpu.sh','env','LD_LIBRARY_PATH='+str(lib.resolve()),'IK_MR=1','GGML_CUDA_GRAPH_CHUNK_SIZE=0']
        command.extend(f'{k}={v}' for k,v in {'IK_MMA':3,**env}.items())
        command.extend(['build/p11/sweep/expert','--cases',str(model)])
        for idx,(name,proj,n,dataset) in enumerate(todo):
            layer=int(dataset[5:]) if dataset.startswith('layer') else 0
            directory='-' if dataset=='uniform' else str(w/f'capture-{dataset}')
            command.extend([proj,str(n),str(layer),directory,str(scratch/f'{idx}.f32')])
        with (replay/(tag+'.log')).open('w') as log:
            result=subprocess.run(command,env={**os.environ,'B_OPERATOR_SWEEP':'1','B_MIN_FREE_MIB':'1200'},stdout=subprocess.PIPE,stderr=log,check=True,text=True)
        lines=[s for s in result.stdout.splitlines() if s.startswith(('gate\t','down\t'))]
        assert len(lines)==len(todo),(tag,len(lines),len(todo))
        for idx,((name,proj,n,dataset),line) in enumerate(zip(todo,lines)):
            fields=line.split(); assert fields[:2]==[proj,str(n)] and len(fields)==12 and all(float(x)>0 for x in fields[3:])
            f=scratch/f'{idx}.f32';assert f.stat().st_size==4*2304*8*n
            with f.open('rb') as buf:digest=hashlib.file_digest(buf,'sha256').hexdigest()
            value=f'{line}\t{digest}\n'
            (replay/(name+'.tsv')).write_text(value)
            dest=out/(name+'.tsv')
            if not dest.exists():dest.write_text(value)
            original=(saved/(name+'.tsv')).read_text().split()[-1]
            if digest!=original:print(tag,name,'different output from initial run',flush=True)
        print(datetime.datetime.now().isoformat(),tag,len(todo),'shapes',flush=True)

if family in ('tiles','geometry','stream'):
    datasets=('uniform','ppl','code','prose')
    if family=='tiles':
        for j in (8,16,24,32,40,48,64,80,96):
            items=sum((cases('tile',f'j{j}' if d=='uniform' else f'prompt-{d}-j{j}',d) for d in datasets),[])
            run(f'tile-{j}',w/'screen-bin',{'P11B_Q2K_J':j,'P11B_Q20_J':j},items)
    elif family=='geometry':
        for geom in ('i64-t128-o1','i64-t128-o3','i64-t128-o5','i32-t64-o4','i128-t256-o2','i128-t256-o3'):
            items=sum((cases('tile',geom if d=='uniform' else f'prompt-{d}-{geom}',d) for d in datasets),[])
            run('geom-'+geom,w/('geom-'+geom),{},items)
    else:
        for waves in ('default',1,2,4,8):
            opts={'P11B_TILE_MIN':101}
            if waves!='default':opts['P11B_STREAM_WAVES']=waves
            items=cases('tile','stream' if waves=='default' else f'waves{waves}','uniform')+cases('tile',f'routed-ppl-stream{waves}','ppl')
            run('stream-'+str(waves),w/'screen-bin',opts,items)
elif family in ('routed','combined','variant','steady','q20','controls','layer5'):
    for leg in ('old1','new1','new2','old2'):
        lib=old;env={};items=[]
        if family=='routed' or family=='layer5':
            for d in (('ppl','code','prose') if family=='routed' else ('layer5',)):
                for suite in ('tile','verify'):items+=cases(suite,f'routed-{d}-{leg}',d)
        elif family=='steady':
            env['P11_STEADY']=1
            for d in ('uniform','ppl','code'):items+=cases('tile',f'steady-{d}-{leg}',d)
        elif family=='combined':
            for suite in ('tile','verify'):items+=cases(suite,'combined-'+leg,'uniform')
        elif family=='variant':
            items=cases('verify',leg,'uniform');env['P11B_VERIFY']=3
        elif family=='q20':
            items=cases('tile','q20j40-'+leg,'uniform');env['P11B_Q20_J']=40
        elif family=='controls':items=cases('tile',leg,'uniform')
        if leg.startswith('new'):
            if family=='variant':lib=w/'verify-bin'
            elif family=='q20':lib=w/'screen-bin'
            elif family!='controls':lib=w/'combined-bin';env['IK_MMA']=7
        run(f'{family}-{leg}',lib,env,items)
else:raise ValueError(family)
