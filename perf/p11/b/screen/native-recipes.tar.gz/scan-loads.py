from pathlib import Path
import sys
p=Path('ggml/src/ggml-cuda/inkling.cu')
s=p.read_text()
key='                            ik_mma_step<G, false, fast, ROW_COLS>'
assert s.count(key)==1
mode=sys.argv[1]
if mode=='late':
 s=s.replace(key,key.replace('false, fast','fast, fast'))
elif mode=='occ2':
 s=s.replace('#define IK_A2_MIN_BLOCKS 1','#define IK_A2_MIN_BLOCKS 2')
 s=s.replace('__launch_bounds__(IK_A2_BLOCK, 1) inkling_attn_window_cols','__launch_bounds__(IK_A2_BLOCK, 2) inkling_attn_window_cols')
elif mode in ('prefetch16','prefetch32'):
 ahead=mode.removeprefix('prefetch')
 code='''                            if constexpr (fast) {
                                const int cell = kt + AHEAD + (lane & 15);
                                if (cell < w1) {
                                    const int offset = (lane >> 4)*64;
                                    asm volatile("prefetch.global.L2 [%0];" :: "l"(kb + cell*args.kc_nb2 + offset));
                                    asm volatile("prefetch.global.L2 [%0];" :: "l"(vb + cell*args.vc_nb2 + offset));
                                }
                            }
'''.replace('AHEAD',ahead)
 s=s.replace(key,code+key)
else: raise ValueError(mode)
p.write_text(s)
