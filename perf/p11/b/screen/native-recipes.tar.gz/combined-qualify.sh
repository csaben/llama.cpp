set -euo pipefail
export BRACKET_NEW="$PWD/build/p11/narrow-bin" BRACKET_NEW_MMA=7 BRACKET_NEW_WINDOW=2 LLAMA_DSPARK_FULL_RATE=1
export B_MMA=7 B_WINDOW_COLS=2
until [[ -s build/p11/narrow-bin.sha256 ]]; do sleep 5; done
out=perf/p11/b/narrow
mkdir -p "$out"
case $1 in
    served|synthetic) bash perf/p11/b/crossover.sh "$1" build/p11/narrow-paired ;;
    matrix) B_LIBS="$BRACKET_NEW" bash perf/p11/b/matrix.sh build/p11/matrix-narrow ;;
    checks) B_EXTRA_PACK=2 B_LIBS="$BRACKET_NEW" bash perf/p11/b/checks.sh "$out/checks" ;;
    logits) B_LOGITS_WORK=build/p11/narrow-checks bash perf/p11/b/logits.sh "$out/logits" ;;
    long) bash perf/p11/b/long-bracket.sh 131072 127872 narrow-128k p9-128k ;;
    ppl)
        export B_LIBS="$BRACKET_NEW"
        B_MR=0 B_MMA=0 perf/p11/b/gpu.sh perf/p11/b/run.sh ppl -c 1024 -b 1024 -ub 1 --chunks 2 >"$out/decode-default.log" 2>&1
        rg 'Final estimate:' "$out/decode-default.log" >"$out/decode-default.txt"
        bash perf/p11/b/ppl-reference.sh "$out/historical-model" ;;
    ops)
        export B_LIBS="$BRACKET_NEW" B_MIN_FREE_MIB=1000
        mkdir -p "$out/ops"
        for spec in MUL_MAT_ID,'m=257,n=512,k=512' INKLING_ATTN,'type_kv=q8_0'; do
            op=${spec%%,*}; filter=${spec#*,}
            log="build/p11/ops/narrow-$op.log"
            perf/p11/b/gpu.sh perf/p11/b/run.sh ops -o "$op" -p "$filter" >"$log" 2>&1
            sed -E 's/\x1B\[[0-9;]*[mK]//g' "$log" | rg 'tests passed|Backend CUDA0:|FAIL' >"$out/ops/$op.txt"
        done ;;
esac
