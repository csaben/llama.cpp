import json,re,statistics,sys
from pathlib import Path
root=Path(sys.argv[1])
legs=('old1','new1','new2','old2')
print('workload\tprompt\told1\tnew1\tnew2\told2\told_mean\tnew_mean\tpct')
def row(name,k,values):
    old=statistics.mean((values[0],values[3])); new=statistics.mean(values[1:3])
    print(name,k,*(f'{v:.2f}' for v in (*values, old, new, 100*(new/old-1))),sep='\t')
for f in sorted(root.glob('*-old1.json')):
    name=f.name.removesuffix('-old1.json')
    files=[root/f'{name}-{leg}.json' for leg in legs]
    if all(f.is_file() and f.stat().st_size for f in files):
        data=[json.loads(f.read_text())[0] for f in files]
        for k in ['model_filename','n_batch','n_ubatch','n_depth','n_gen','n_prompt','type_k','type_v','tensor_buft_overrides']:
            assert len({d[k] for d in data})==1, (name,k)
        row(name,'-', [d['avg_ts'] for d in data])
for d in sorted(root.iterdir()):
    if not d.is_dir():continue
    files=[d/f'{leg}.txt' for leg in legs]
    if not all(f.is_file() and f.stat().st_size for f in files):continue
    tables=[{p[1]:float(p[6]) for line in f.read_text().splitlines() if len(p:=line.split())>=9} for f in files]
    if not tables or not tables[0] or not all(t.keys()==tables[0].keys() for t in tables):continue
    for k in tables[0]:
        for ext in ['ids','json']:
            assert len({(d/f'{leg}.{k}.{ext}').read_bytes() for leg in legs})==1
        row(d.name,k,[t[k] for t in tables])
