"""Extract the committed target tokens from the p9 rollback trace."""
import gzip
from pathlib import Path
context = memory = None
tokens = []
for line in gzip.open('perf/p6/r4_repro/n3.trace.gz','rt'):
    entry = line.split()
    if entry[0] == 'D':
        if context is None:
            context,memory = entry[1:3]
        if entry[1] != context:
            continue
        for item in entry[4:]:
            pos,tok,_ = map(int,item.split(':'))
            if pos == len(tokens): tokens.append(tok)
            else: tokens[pos] = tok
    elif entry[0] == 'C' and entry[1] == memory: tokens.clear()
    elif entry[0] == 'R' and entry[1] == memory and int(entry[-1]): del tokens[int(entry[3]):]
assert len(tokens) == 2724
out=Path('build/p11/managed/window-tokens.txt')
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text('\n'.join(map(str,tokens))+'\n')
