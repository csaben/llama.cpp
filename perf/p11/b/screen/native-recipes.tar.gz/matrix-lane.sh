set -euo pipefail
version=${1:?} suite=${2:?}
export B_MATRIX_SUITES=$suite
if [[ $suite == main ]]; then export B_MATRIX_BUDGETS=3000; fi
if [[ $version == narrow ]]; then
    export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1
fi
bash perf/p11/b/matrix.sh "build/p11/matrix-$version"
