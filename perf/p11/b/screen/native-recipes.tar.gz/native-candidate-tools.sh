set -euo pipefail
e=perf/p11/b/narrow/ops
mkdir -p "$e"
export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 IK_WINDOW_COLS=2 B_OPERATOR_SWEEP=1 LLAMA_DSPARK_FULL_RATE=1
B_MIN_FREE_MIB=1300 perf/p11/b/gpu.sh perf/p11/b/run.sh ops --test-file perf/p11/b/screen/window.ops >build/p11/ops/all-narrow-native.log 2>&1
sed -E 's/\x1B\[[0-9;]*[mK]//g' build/p11/ops/all-narrow-native.log | rg '18/18 tests passed|Backend CUDA0: OK' >"$e/model-shapes.txt"
rg -q '18/18 tests passed' "$e/model-shapes.txt"
P11_SAN_DIR="$e" P11_SAN_PREFIX=verified-narrow bash build/p11/narrow-sanitize.sh
date --iso-8601=seconds >"$e/native-tools-completed.txt"
