"""Archive completed partial release-matrix cells and corresponding same-model, frozen controls."""
from pathlib import Path
from collections import Counter
import csv,hashlib,io,subprocess,sys,tarfile

version=sys.argv[1]
assert version in ('p9','narrow')
w=Path('build/p11')
root=w/f'matrix-{version}'
p9=w/'matrix-p9'
text=subprocess.check_output([sys.executable,str(w/'partial-matrix.py'),str(root)],text=True)
rows=list(csv.DictReader(io.StringIO(text),delimiter='\t'))
assert len({(r['suite'],r['budget'],r['setting'],r['prompt']) for r in rows})==len(rows)
out=Path('perf/p11/b')/f'matrix-{version}'
out.mkdir(exist_ok=True)
files={}
proven=[r for r in rows if r['p9_plain']=='1']
for r in proven:
    cell=Path(r['suite'])/r['budget']
    setting,prompt=r['setting'],r['prompt']
    for ext,key in [('ids','ids_sha256'),('json','message_sha256')]:
        name=f'{setting}.{prompt}.{ext}'
        ref=f'plain.{prompt}.{ext}'
        item=(root/cell/name).read_bytes()
        assert item==(root/cell/ref).read_bytes()==(p9/cell/ref).read_bytes()
        assert hashlib.sha256(item).hexdigest()==r[key]
        for snapshot,file in [('tested',name),('tested',ref),('frozen',ref)]:
            files[str(Path(snapshot)/cell/file)]=item
    summary=(root/cell/f'{setting}.txt').read_text().splitlines()
    line,=[x for x in summary if x.split()[1]==prompt]
    files[str(Path('tested')/cell/f'{setting}.{prompt}.txt')]=(line+'\n').encode()

table=io.StringIO();writer=csv.DictWriter(table,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n')
writer.writeheader();writer.writerows(proven)
files['progress.tsv']=table.getvalue().encode()
drafted=[r for r in proven if r['setting']!='plain']
audit=f"{len(proven)}/194 cells compared with both plain controls. {len(drafted)} drafted cells, {sum(int(r['replies']) for r in drafted)} drafted replies, {sum(int(r['ids']) for r in drafted):,} IDs. Every archived message and ID matched.\n"
files['progress.txt']=audit.encode()
archive=out/'matched-progress.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for name,data in sorted(files.items()):
        meta=tarfile.TarInfo(name);meta.size=len(data);t.addfile(meta,io.BytesIO(data))
with tarfile.open(archive) as t:
    for name,data in files.items():assert t.extractfile(name).read()==data
(out/'progress.tsv').write_bytes(files['progress.tsv'])
(out/'progress.txt').write_text(audit)
print(version,audit,end='')
