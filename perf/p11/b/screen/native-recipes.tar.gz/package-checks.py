from pathlib import Path
import csv,re,sys,tarfile
name=sys.argv[1]
root=Path('perf/p11/b')/name/'checks'
expect_pack=(0,1,2) if name=='narrow' else (0,1)
standard=['trace',*[f'boundary-{d}' for d in (1533,3069,4500)],'legacy-3069',*[f'rollback-{d}' for d in (2000,2046,2558,3069,4094,4500)]]
also=[f'wide-{pack}-{d}' for pack in expect_pack for d in (200,4096,16384,32768)]+[f'cost-{w}' for w in range(2,8)]
data=[];paths=[]
for test in standard+also:
 path=root/(test+'.log')
 if not path.exists():continue
 txt=path.read_text(errors='replace')
 m=re.search(r'(\d+) (?:output )?rows (?:up to position|in \d+ steps)[^\n]*: (\d+) rows differ from single-token decode, max \|logit diff\| ([^\s]+)',txt)
 if not m:continue
 count,bad,error=m.groups()
 assert int(bad)==0 and float(error)==0,(path,bad,error)
 if test.startswith('wide-'):assert int(count)==182
 data.append((test,int(count),int(bad),float(error)));paths.append(path)
if '--partial' not in sys.argv:
 assert len(data)==len(standard+also)
 assert sum(r[1] for r in data if r[0] in standard)==2714
if data:
 with (root/'native-rows.tsv').open('w') as f:
  writer=csv.writer(f,delimiter='\t',lineterminator='\n')
  writer.writerow(('check','full_vocab_rows','different_rows','max_abs_logit_difference'))
  writer.writerows(data)
 with tarfile.open(root/'native-logs.tar.gz','w:gz') as t:
  for p in paths:t.add(p,arcname=p.name,recursive=False)
 with tarfile.open(root/'native-logs.tar.gz') as t:
  assert all(t.extractfile(p.name).read()==p.read_bytes() for p in paths)
print(name,len(data),'checks,',sum(r[1] for r in data),'rows, all bit-exact')
