set -euo pipefail
d=build/p11/preflight-logits
mkdir -p "$d"
for v in p9 bias-bin geom-i64-t128-o1 geom-i32-t64-o4 id-bin; do
    libs="$PWD/build/p11/$v"
    if [[ $v == p9 ]]; then libs="$HOME/inkling-live-bin-p9-72fd097"; fi
    B_LIBS="$libs" perf/p11/b/gpu.sh perf/p11/b/run.sh logits 4096 2 >"$d/$v.f32" 2>"$d/$v.log"
    test "$(stat -c %s "$d/$v.f32")" = 1600464
    sha256sum "$d/$v.f32"
done
