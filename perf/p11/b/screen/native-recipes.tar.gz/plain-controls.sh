set -euo pipefail
for suite in prose fixed; do
    kinds=letter,science,scene,review,dialogue; export B_POLICY=1 B_ADAPT=0
    if [[ $suite == fixed ]]; then kinds=code,edit,prose,edit@16K,edit@32K,agent; B_POLICY=0; fi
    d="build/p11/matrix-p9/$suite/3000"
    perf/p11/b/gpu.sh perf/p11/b/run.sh probe "$d" plain 0 "$kinds" 1 3000
    python3 perf/p11/b/probe_complete.py "$d" plain "$kinds" 1 3000
done
