set -euo pipefail
export P11_EXPERT_INPUT_DIR="$PWD/build/p11/capture-ppl"
for waves in default 1 2 4 8; do
    opts=(P11B_TILE_MIN=101)
    if [[ $waves != default ]]; then opts+=(P11B_STREAM_WAVES=$waves); fi
    env "${opts[@]}" perf/p11/b/screen/micro.sh "$PWD/build/p11/screen-bin" tile "routed-ppl-stream$waves"
done
