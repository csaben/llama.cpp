#!/usr/bin/env bash
# Compile the standalone CPU drivers. Device code comes from the runtime selected per measurement.
set -euo pipefail
d=${1:-build/p11}
mkdir -p "$d"
cxx=(g++ -std=c++17 -O2 -Wno-deprecated-declarations -Iinclude -Iggml/include)
for program in attention expert prompt_attention window_ops capture; do
    output=${program//_/-}
    "${cxx[@]}" "perf/p11/b/screen/$program.cpp" -Lbuild/bin -Wl,-rpath-link,build/bin -lllama -lggml -lggml-base -o "$d/$output"
done
ln -f "$d/attention" "$d/attention-steady"
ln -f "$d/expert" "$d/expert-q8"
ln -f "$d/capture" "$d/capture-windows"
