set -euo pipefail
kind=$1
while [[ $(date +%H%M) < 0730 && ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]]; do
    if [[ -s build/p11/bench-grid/$kind-output-new.done && -s build/p11/bench-grid/$kind-timed-old2.done ]]; then
        exec "$HOME/llama.cpp-fast/.venv/bin/python" perf/p11/b/bench_grid.py "$kind"
    fi
    sleep 20
done
