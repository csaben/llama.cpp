set -eu
for name in ppl code prose; do
    export P11_EXPERT_INPUT_DIR="$PWD/build/p11/capture-$name"
    for geom in i64-t128-o1 i64-t128-o3 i64-t128-o5 i32-t64-o4 i128-t256-o2 i128-t256-o3; do
        perf/p11/b/screen/micro.sh "$PWD/build/p11/geom-$geom" tile "prompt-$name-$geom"
    done
done
