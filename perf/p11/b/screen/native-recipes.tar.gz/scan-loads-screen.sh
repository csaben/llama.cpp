set -euo pipefail
while ! rg -q 'Built target ggml-cuda$' build/p11/scan-rebuild-clean.log 2>/dev/null; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
    sleep 15
done
export B_SCAN_WIDTHS='1 4 7'
B_LIBS="$PWD/build/p11/release-bin" perf/p11/b/screen/scan.sh loads-base
for variant in late occ2 prefetch16 prefetch32; do
    B_LIBS="$PWD/build/p11/scan-$variant-bin" perf/p11/b/screen/scan.sh "loads-$variant"
done
B_LIBS="$PWD/build/p11/release-bin" perf/p11/b/screen/scan.sh loads-base2
