import csv,hashlib,sys
from pathlib import Path
root=Path(sys.argv[1]);frozen=Path('build/p11/matrix-p9')
out=csv.writer(sys.stdout,delimiter='\t',lineterminator='\n')
out.writerow(['suite','budget','setting','prompt','replies','ids','ids_sha256','message_sha256','p9_plain'])
for table in sorted(root.glob('*/*/*.txt')):
    suite,budget=table.relative_to(root).parts[:2]
    if budget not in ('384','3000'):continue
    for line in table.read_text().splitlines():
        t=line.split()
        if len(t)<9 or t[0]!=table.stem or t[2]!='prompt' or t[4]!=budget: continue
        name=t[1];ds=(root/suite/budget);p9=frozen/suite/budget
        refs=(ds/f'plain.{name}.ids',ds/f'plain.{name}.json')
        if not all(x.exists() for x in refs):continue
        digests=[];matched=True
        for ext,ref in zip(['ids','json'],refs):
            p=ds/f'{table.stem}.{name}.{ext}'; data=p.read_bytes()
            assert data==ref.read_bytes(),p
            if ext=='ids':assert len(data)==int(budget)*4
            old=p9/f'plain.{name}.{ext}'
            if old.exists() and old.stat().st_size:
                assert data==old.read_bytes(),(p,old)
            else:matched=False
            digests.append(hashlib.sha256(data).hexdigest())
        reps=(5 if suite=='prose' else 3) if budget=='384' else 1
        if reps>1:assert t[-2]=='runs' and len(t[-1].split('/'))==reps
        out.writerow([suite,budget,table.stem,name,reps,reps*int(budget),*digests,int(matched)])
