from pathlib import Path
import csv,hashlib,sys
import gguf
d=Path.home()/'models/inkling-2-mini'
paths=[d/('Inkling-2-Mini-'+s+'.gguf') for s in ('AtomicChat-Uncensored-Q2K-Q2_0-fit','experimental-Q2K-Q2_0-fit','IQ4_NL-dense-iq4nl')]
writer=csv.writer(sys.stdout,delimiter='\t',lineterminator='\n')
keys=('tokenizer.ggml.tokens','tokenizer.ggml.token_type','tokenizer.ggml.merges')
writer.writerow(['model','file_bytes','output_type','output_shape','output_sha256',*keys])
all_digests=[]
for p in paths:
 r=gguf.GGUFReader(str(p))
 t=next(t for t in r.tensors if t.name=='output.weight')
 digests=[hashlib.sha256(t.data).hexdigest()]
 for key in keys:
  h=hashlib.sha256()
  for block in r.fields[key].parts:h.update(block)
  digests.append(h.hexdigest())
 all_digests.append(digests)
 writer.writerow([p.name,p.stat().st_size,t.tensor_type.name,'x'.join(map(str,t.shape)),*digests])
assert all(row==all_digests[0] for row in all_digests)
