set -euo pipefail
export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1
export MR_RS_A=0 MR_RS=4 MR_RAND=37 MR_SIZES=2,3,4,5 MR_PLAIN_PCT=15 MR_PLAIN_RUN=8
for depth in "$@"; do
    dest="perf/p11/b/narrow/checks/rollback-$depth.log"
    if [[ -e $dest ]]; then continue; fi
    tmp="build/p11/independent-rollback-$depth.log"
    perf/p11/b/gpu.sh perf/p11/b/run.sh mr perf/ppl.txt "$depth" 64 >"$tmp" 2>&1
    rg -q '126 rows .*: 0 rows differ from single-token decode, max \|logit diff\| 0$' "$tmp"
    if [[ ! -e $dest ]]; then cp "$tmp" "$dest"; fi
done
