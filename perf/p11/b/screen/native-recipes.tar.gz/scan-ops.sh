set -euo pipefail
for var in late occ2 prefetch16 prefetch32; do
    d="$PWD/build/p11/scan-$var-bin"
    while ! [[ -s "$d/libggml-cuda.so.1" ]] || ! [[ -s build/p11/scan-rebuild-clean.log ]]; do
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
        sleep 10
    done
    log="build/p11/ops/scan-$var.log"
    B_LIBS="$d" B_MIN_FREE_MIB=1000 perf/p11/b/gpu.sh perf/p11/b/run.sh ops -o INKLING_ATTN -p 'type_kv=q8_0' >"$log" 2>&1
    sed -E 's/\x1B\[[0-9;]*[mK]//g' "$log" | rg 'tests passed|Backend CUDA0:|FAIL' >"perf/p11/b/screen/ops/scan-$var-INKLING_ATTN.txt"
    rg -q ' 8/8 tests passed' "perf/p11/b/screen/ops/scan-$var-INKLING_ATTN.txt"
done
