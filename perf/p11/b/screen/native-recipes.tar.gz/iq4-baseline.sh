set -euo pipefail
export B_MODEL="$HOME/models/inkling-2-mini/Inkling-2-Mini-IQ4_NL-dense-iq4nl.gguf" B_CTX=65536
d=perf/p11/b/iq4-p9
mkdir -p "$d"
gpu=(perf/p11/b/gpu.sh perf/p11/b/run.sh)
for depth in 0 4096 16384 32768 65536; do
    "${gpu[@]}" bench -p 0 -n 128 -d "$depth" -r 3 >"$d/tg-$depth.json" 2>"$d/tg-$depth.log"
done
for depth in 4096 16384 65536; do
    "${gpu[@]}" bench -p "$depth" -n 0 -r 3 >"$d/pp-$depth.json" 2>"$d/pp-$depth.log"
done
for width in 6 0; do "${gpu[@]}" probe "$d/short" "n$width" "$width" code,edit,prose,agent 1 3000; done
SPEC_KINDS=code,edit,prose,agent SPEC_REQUIRE_IDS=1 python3 perf/p6/r4_cmp.py "$d/short" n0 n6 >"$d/short/equality.txt"
for ctx in 81920 98304; do
    label="iq4-p9-$ctx"
    if perf/p11/b/gpu.sh perf/p11/b/long.sh "$ctx" "$((ctx-3200))" 6 "$label" >"build/p11/$label.log" 2>&1; then
        perf/p11/b/gpu.sh perf/p11/b/long.sh "$ctx" "$((ctx-3200))" 0 "$label" >>"build/p11/$label.log" 2>&1
    else
        rg -i 'out of memory|failed to allocate' "build/p11/long/$label-dspark.server" >"perf/p11/b/long/$label-oom.txt"
        break
    fi
done
for type in prefill decode; do
    opts=(-c 2048 -b 2048 -ub 512 --chunks 8)
    if [[ $type == decode ]]; then opts=(-c 1024 -b 1024 -ub 1 --chunks 2); fi
    "${gpu[@]}" ppl "${opts[@]}" >"$d/$type.log" 2>&1
    rg 'Final estimate' "$d/$type.log" >"$d/$type.txt"
done
