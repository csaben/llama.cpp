set -euo pipefail
for ctx in 196608 229376 245760 262144; do
    dir=build/p11/long
    label="p9-slot-$ctx"
    if perf/p11/b/gpu.sh perf/p11/b/long.sh "$ctx" "$((ctx-3200))" 6 "$label" >"build/p11/$label.log" 2>&1; then
        perf/p11/b/gpu.sh perf/p11/b/long.sh "$ctx" "$((ctx-3200))" 0 "$label" >>"build/p11/$label.log" 2>&1
    else
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
        rg -i 'out of memory|failed to allocate' "$dir/$label-dspark.server" >"perf/p11/b/long/$label-oom.txt"
        break
    fi
done
