set -euo pipefail
d=perf/p11/b/screen
s=build/p11
case ${1:?} in
    capture)
        python3 "$s/capture-inputs.py"
        model="$HOME/models/inkling-2-mini/Inkling-2-Mini-AtomicChat-Uncensored-Q2K-Q2_0-fit.gguf"
        for name in ppl code prose layer5 layer12; do
            P11_LAYER=0;input=perf/ppl.txt
            if [[ $name == code ]]; then input="$s/capture-inputs/edit.txt"; fi
            if [[ $name == prose ]]; then input="$s/capture-inputs/story.txt"; fi
            if [[ $name == layer* ]]; then P11_LAYER=${name#layer}; fi
            export P11_LAYER
            cap="$s/capture-$name"
            mkdir -p "$cap"
            if [[ -s "$cap/fresh.sha256" ]] && (cd "$cap" && sha256sum -c fresh.sha256 >/dev/null); then continue; fi
            B_MIN_FREE_MIB=1300 perf/p11/b/gpu.sh env LD_LIBRARY_PATH="$HOME/inkling-live-bin-p9-72fd097" LLAMA_INKLING_CTRL_F16=1 IK_MR=1 IK_MMA=3 timeout 140 "$s/capture" "$model" "$input" "$cap" >"$cap/out.txt" 2>"$cap/log.txt"
            (cd "$cap" && sha256sum {gate,down}.{input,ids,output}) >"$cap/fresh.sha256"
            if [[ -f "$s/occupied/screen/routed-$name/capture.sha256" ]]; then cmp "$cap/fresh.sha256" "$s/occupied/screen/routed-$name/capture.sha256"; fi
        done ;;
    micro)
        bash "$s/micro-screen.sh" verify
        python3 "$d/summarize_micro.py" "$d/micro" verify >"$d/verify-bracket.tsv"
        bash "$s/micro-winners.sh"
        python3 "$d/summarize_micro.py" "$d/micro" tile q20j40- >"$d/q20-j40-bracket.tsv"
        bash "$s/combined-micro.sh"
        bash "$s/micro-screen.sh" tile ;;
    routed|extra|steady)
        for name in ppl code prose layer5 layer12; do
            until [[ -s "$s/capture-$name/fresh.sha256" ]]; do
                [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
                sleep 10
            done
            if [[ $1 == routed ]]; then
                layer=0; if [[ $name == layer* ]]; then layer=${name#layer}; fi
                P11_LAYER=$layer bash "$s/routed-screen.sh" "$name"
            fi
        done
        if [[ $1 == extra ]]; then bash "$s/routed-tiles.sh"; bash "$s/routed-geometry.sh"; bash "$s/routed-stream.sh"; bash "$s/onetensor-profile.sh"; fi
        if [[ $1 == steady ]]; then bash "$s/steady.sh"; fi ;;
    scan)
        bash "$s/scan-bracket.sh"
        bash "$s/scan-screen.sh"
        bash "$s/scan-loads-screen.sh"
        python3 "$d/scan_results.py" "$d/scan" >"$d/scan-results.tsv"
        python3 "$d/scan_results.py" "$d/scan" paired >"$d/packed-bracket.tsv" ;;
    tests)
        for script in test-windows narrow-sanitize micro-ops scan-ops fallback-ops; do bash "$s/$script.sh"; done ;;
    *) exit 2 ;;
esac
date --iso-8601=seconds >"build/p11/native-recheck-$1.done"
