set -euo pipefail
v=$1
export B_MATRIX_SUITES=$2 B_MATRIX_BUDGETS=$3
if [[ $v == narrow ]]; then export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1; fi
bash perf/p11/b/matrix.sh "build/p11/matrix-$v"
