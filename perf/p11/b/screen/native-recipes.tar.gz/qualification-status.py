from pathlib import Path
import csv,re,subprocess,sys
root=Path('build/p11')
e=Path('perf/p11/b')
name=sys.argv[1] if len(sys.argv)>1 else 'narrow'
d=e/name
pair=root/('narrow-paired' if name=='narrow' else 'paired')
matrix=root/('matrix-narrow' if name=='narrow' else 'matrix-new')
def ok(path):return path.is_file() and path.stat().st_size>0
def quality(p):
 if ok(p):
  m=re.search(r'Final estimate: PPL = ([\d.]+)',p.read_text());return float(m[1]) if m else None
def report(label,values):
 print(label,', '.join(str(v) for v in values))
rows=[f for f in (d/'checks').glob('*.log') if ok(f) and re.search(r': 0 rows differ from single-token decode, max \|logit diff\| 0$',f.read_text(errors='replace'),re.M)]
report('Numerical checks',[f'{len(rows)} complete',f'{sum(int(x[1]) for p in rows if (x:=re.search(r"(\d+) (?:output )?rows (?:in|up to)",p.read_text(errors="replace"))))} rows across those checks'])
report('PPL',[(str(p.relative_to(d)),quality(p)) for p in [d/'checks/prefill.txt',d/'checks/decode.txt',d/'decode-default.txt',*(d/'historical-model'/n for n in ['prefill.txt','decode-mr.txt','decode-default.txt'])]])
report('Logit depths',[p.stem for p in (d/'logits').glob('*.sha256') if ok(p)])
report('Direct synthetic outputs',[p.stem for p in (d/'bench-logits').glob('*.txt') if ok(p)])
report('Complete synthetic brackets',[p.name[:-10] for p in pair.glob('*-old2.json') if ok(p) and p.stat().st_size>20])
report('Complete served brackets',[p.name for p in pair.iterdir() if p.is_dir() and ok(p/'old2.equal')])
report('Long brackets',[p.stem for p in (e/'long').glob(f'{name}-128k-*.equal') if ok(p)])
report('Matrix',[f'{len(list(matrix.glob("*/*/*.ids")))} / 194 captured cells',f'full TSV {ok(matrix/"cells.tsv")}'])
