set -euo pipefail
d=build/p11/profiles
out=perf/p11/b/profiles
for leg in old1 new1 new2 old2; do
    tag="tuned-$leg"
    export B_LIBS="$HOME/inkling-live-bin-p9-72fd097" B_MMA=3 B_WINDOW_COLS=1 LLAMA_DSPARK_FULL_RATE=0 B_MIN_FREE_MIB=18500
    if [[ $leg == new* ]]; then B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1; fi
    bash perf/p11/b/profile.sh verify "$tag"
    for ext in ids json; do cmp "$d/$tag-verify.edit.$ext" "$d/p9-verify.edit.$ext"; done
    python3 perf/p11/b/verify_cost.py "$d/$tag-verify.sqlite" >"$out/$tag-graphs.tsv"
    python3 perf/p11/b/verify_parts.py "$d/$tag-verify.sqlite" >"$out/$tag-kernel-shares.tsv"
    python3 perf/p11/b/profile_evidence.py "$d/$tag-verify.sqlite" "perf/p11/b/$tag-verify-kernels.csv" "$out/$tag-verify.sqlite.xz"
done
