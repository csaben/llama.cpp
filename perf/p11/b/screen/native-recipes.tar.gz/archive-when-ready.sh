set -euo pipefail
v=${1:?matrix version}
while [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]]; do
    if [[ -s perf/p11/b/matrix-$v/captures.tar.gz ]]; then exit 0; fi
    n=$(find "build/p11/matrix-$v" -name '*.ids' -type f | wc -l)
    if ((n==194)) && bash build/p11/archive-matrix.sh "$v"; then
        cat "perf/p11/b/matrix-$v/audit.txt"
        exit 0
    fi
    sleep 45
done
