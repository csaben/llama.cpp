from pathlib import Path
from collections import Counter
import sys,tarfile,csv
root=Path('perf/p11/b/screen')
counts=Counter()
out=csv.writer(sys.stdout,delimiter='\t',lineterminator='\n')
out.writerow(('operator','sample','state','overlap_output_sha256','native_output_sha256'))
with tarfile.open(root/'overlap-operator-samples.tar.gz') as archive:
 for x in archive.getmembers():
  if x.name=='index.tsv':continue
  op,sample=x.name.split('/')
  old=archive.extractfile(x).read().split()[-1].decode()
  path=root/('micro' if op=='expert' else 'scan')/sample
  new=(path.read_text().split()[-1] if path.is_file() and path.stat().st_size else '')
  state='pending' if not new else ('matching' if new==old else 'changed')
  counts[op,state]+=1
  out.writerow((op,sample,state,old,new or '-'))
print(dict(sorted(counts.items())),file=sys.stderr)
