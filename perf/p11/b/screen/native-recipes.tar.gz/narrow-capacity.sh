set -euo pipefail
export B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2 LLAMA_DSPARK_FULL_RATE=1
while [[ ! -s perf/p11/b/long/narrow-128k-new1.equal ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
    sleep 20
done
for ctx in 196608 229376 245760; do
    depth=$((ctx-3200));name="narrow-slot-$ctx";base="build/p11/long/$name"
    if ! perf/p11/b/gpu.sh perf/p11/b/long.sh "$ctx" "$depth" 6 "$name" >"build/p11/$name.log" 2>&1; then
        rg -i 'out of memory|failed to allocate' "$base-dspark.server" >"perf/p11/b/long/$name-oom.txt"
        break
    fi
    perf/p11/b/gpu.sh perf/p11/b/long.sh "$ctx" "$depth" 0 "$name" >>"build/p11/$name.log" 2>&1
    python3 - "$ctx" "$depth" <<'PY'
import json,sys,struct,hashlib
from pathlib import Path
c,d=sys.argv[1:];root=Path('build/p11/long')
items=[json.loads((root/f'{build}-slot-{c}-{mode}-edit-{d}.json').read_text()) for build,mode in [('p9','plain'),('narrow','plain'),('narrow','dspark')]]
assert all(x['message']==items[0]['message'] and x['ids']==items[0]['ids'] and x['timings']['prompt_n']==int(d) and len(x['ids'])==3000 for x in items)
assert items[-1]['timings']['draft_n_accepted']>0
Path(f'perf/p11/b/long/narrow-slot-{c}.equal').write_text(f'Plain and DSpark matched the complete p9 message and all 3000 IDs. ID SHA-256 {hashlib.sha256(struct.pack("<3000i",*items[0]["ids"])).hexdigest()}\n')
PY
done
