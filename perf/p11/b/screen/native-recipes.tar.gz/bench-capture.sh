set -euo pipefail
w=build/p11/bench-capture
out=perf/p11/b/narrow/bench-logits
mkdir -p "$out"
export B_BENCH_TOOL="$PWD/$w/llama-bench"
for cell in tg0 tg4096 tg16384 tg32768 tg65536 pp4096 pp16384 pp65536; do
    args=(-p 0 -n 128 -d "${cell#tg}" -r 3)
    if [[ $cell == pp* ]]; then args=(-p "${cell#pp}" -n 0 -r 3); fi
    for version in p9 narrow; do
        export B_LIBS="$HOME/inkling-live-bin-p9-72fd097" B_MMA=3 B_WINDOW_COLS=1
        if [[ $version == narrow ]]; then B_LIBS="$PWD/build/p11/narrow-bin" B_MMA=7 B_WINDOW_COLS=2; fi
        export P11_BENCH_DUMP="$PWD/$w/$cell-$version.bin"
        perf/p11/b/gpu.sh perf/p11/b/run.sh bench "${args[@]}" >"$w/$cell-$version.json" 2>"$w/$cell-$version.log"
    done
    cmp "$w/$cell-p9.bin" "$w/$cell-narrow.bin"
    "$HOME/llama.cpp-fast/.venv/bin/python" - "$w" "$cell" <<'PY' >"$out/$cell.txt"
from pathlib import Path
import hashlib,sys
import numpy as np
d=Path(sys.argv[1]);name=sys.argv[2]
tokens,logits=hashlib.sha256(),hashlib.sha256()
nrows=ntokens=0
with (d/f'{name}-p9.bin').open('rb') as f:
 while size:=f.read(4):
  assert len(size)==4
  count=int.from_bytes(size,'little',signed=True)
  assert 0<count<=2048
  ids=f.read(4*count); data=f.read(4*200058)
  assert len(ids)==count*4 and len(data)==4*200058 and np.isfinite(np.frombuffer(data,'<f4')).all()
  tokens.update(size+ids);logits.update(data);nrows+=1;ntokens+=count
assert nrows>0
print(f'{name}: {nrows} matching full-vocabulary rows, {ntokens} matching input IDs, 200058 finite FP32 values per row')
print('Input and batch-size SHA-256',tokens.hexdigest())
print('Full logit SHA-256',logits.hexdigest())
PY
done
