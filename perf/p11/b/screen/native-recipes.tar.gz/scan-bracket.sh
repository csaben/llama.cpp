set -eu
export B_SCAN_WIDTHS='4 5 6 7'
for leg in old1 new1 new2 old2; do
    cols=1
    if [[ $leg == new* ]]; then cols=2; fi
    IK_WINDOW_COLS=$cols perf/p11/b/screen/scan.sh "packed-$leg"
done
