set -euo pipefail
label=$1
run=perf/p11/b/screen/scan.sh
export B_REPLAY_SLOT=$2
case $label in
    splits6|splits14|splits24) IK_ATTN_MMA_SPLITS=${label#splits} "$run" "$label" ;;
    spw2) IK_ATTN_MMA_SPW=2 "$run" "$label" ;;
    packed) IK_WINDOW_COLS=2 "$run" "$label" ;;
    external) B_SCAN_WIDTHS=1 IK_ATTN_SCAN_MIN=2048 "$run" "$label" ;;
    window-scan) B_SCAN_WIDTHS="2 3 4 5 6 7" IK_WINDOW_COLS=0 IK_WINDOW_SCAN_MIN=2048 "$run" "$label" ;;
    tiled) IK_WINDOW_COLS=0 IK_WINDOW_TILE_ROWS=4 "$run" "$label" ;;
    base2|base) "$run" "$label" ;;
    loads-*) export B_SCAN_WIDTHS='1 4 7'; lib="$PWD/build/p11/scan-${label#loads-}-bin"
        if [[ $label == loads-base* ]]; then lib="$PWD/build/p11/release-bin"; fi
        B_LIBS="$lib" "$run" "$label" ;;
    *) exit 2 ;;
esac
