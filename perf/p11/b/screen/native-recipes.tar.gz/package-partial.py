"""Preserve completed legs that did not constitute a qualified performance crossover."""
from pathlib import Path
import csv,hashlib,io,json,re,subprocess,tarfile
work=Path('build/p11')
dest=Path('perf/p11/b/narrow')
files={};rows=[];legs=['old1','new1','new2','old2']
def add(k,p):
 data=p.read_bytes()
 if k in files:assert files[k]==data
 files[k]=data
def bench(path,category,leg):
 data=json.loads(path.read_bytes())
 assert all(r['avg_ts']>0 and len(r['samples_ts'])==3 for r in data)
 for r in data:
  key='pp'+str(r['n_prompt']) if r['n_prompt'] else 'tg'+str(r['n_depth'])
  rows.append((category,key,'-',leg,r['avg_ts'],'raw timing only'))
 add(category+'/'+path.name,path)
for p in sorted((work/'narrow-paired').glob('*.json')):
 if p.stat().st_size>20:bench(p,'individual-bench',p.stem.split('-')[-1])
for p in sorted((work/'bench-grid').glob('*-timed-*.json')):
 if p.with_suffix('.done').exists():bench(p,'grouped-bench',p.stem.split('-')[-1])
for group in ('short3000','deep384','deep3000'):
 budget=int(re.search(r'\d+',group)[0])
 kinds=['edit@16K','edit@32K'] if group.startswith('deep') else ['code','edit','prose','agent']
 d=work/'narrow-paired'/group
 for leg in legs:
  if subprocess.run(['python3','perf/p11/b/probe_complete.py',str(d),leg,','.join(kinds),'3' if budget==384 else '1',str(budget)]).returncode:continue
  summary=d/(leg+'.txt');add(group+'/'+summary.name,summary)
  for r in [line.split() for line in summary.read_text().splitlines()]:
   prompt=r[1]
   for ext in ('json','ids'):
    f=d/f'{leg}.{prompt}.{ext}'; data=f.read_bytes()
    for v in ('p9','narrow'):
     control=work/f'matrix-{v}'/'main'/str(budget)/f'plain.{prompt}.{ext}'
     assert control.read_bytes()==data;add(f'{group}/{v}-{control.name}',control)
    if ext=='ids':assert len(data)==budget*4
    else:assert any(json.loads(data).get(x) for x in ('content','reasoning_content','tool_calls'))
    add(group+'/'+f.name,f)
   rows.append(('served',group,prompt,leg,r[6],'matched p9 and candidate plain'))
table=io.StringIO()
w=csv.writer(table,delimiter='\t',lineterminator='\n')
w.writerow(('scope','case','prompt','leg','tok_s','interpretation'));w.writerows(rows)
files['partial-legs.tsv']=table.getvalue().encode()
(dest/'partial-legs.tsv').write_bytes(files['partial-legs.tsv'])
archive=dest/'partial-captures.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(files.items()):
  meta=tarfile.TarInfo(name);meta.size=len(data);t.addfile(meta,io.BytesIO(data))
with tarfile.open(archive) as t:
 assert all(t.extractfile(n).read()==d for n,d in files.items())
print(len(rows),'individual, grouped or served raw leg records archived')
