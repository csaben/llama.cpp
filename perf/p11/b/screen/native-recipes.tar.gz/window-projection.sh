set -euo pipefail
model=${1:?model} projection=${2:?projection} capture=${3:?source directory} base=${4:?output prefix}
widths=()
args=()
for width in 2 3 4 5 6 7; do
    if [[ -s "$base-$width.tsv" ]]; then continue; fi
    widths+=("$width")
    args+=("$width" "$base-$width.f32")
done
if ((${#widths[@]} == 0)); then exit 0; fi
P11_EXPERT_Q8=1 P11_STEADY=1 P11_EXPERT_WINDOW_DIR="$capture" B_OPERATOR_SWEEP=1 B_MIN_FREE_MIB=1100 perf/p11/b/gpu.sh env \
    IK_MR=1 GGML_CUDA_GRAPH_CHUNK_SIZE=0 build/p11/sweep/expert "$model" "$projection" "${args[@]}" >"$base.times" 2>"$base.log"
for width in "${widths[@]}"; do
    if [[ ${P11_REQUIRE_GRAPH_OUTPUT:-1} == 1 ]]; then cmp "$base-$width.f32" "$capture/$width/$projection.output"; fi
    times=$(awk -v n="$width" -v p="$projection" '$1==p && $2==n && NF==12 {print; found++} END {exit found!=1}' "$base.times")
    printf '%s\t%s\n' "$times" "$(sha256sum "$base-$width.f32" | cut -d' ' -f1)" >"$base-$width.tsv"
done
