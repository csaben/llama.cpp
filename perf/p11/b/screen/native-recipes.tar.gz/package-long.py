import csv,hashlib,io,json,re,struct,sys,tarfile
from pathlib import Path

name=sys.argv[1] if len(sys.argv)>1 else 'narrow'
raw=Path('build/p11/long'); evidence=Path('perf/p11/b/long')
rows=[];files={}
for capture in sorted(raw.glob(name+'-*-edit-*.json')):
    match=re.fullmatch(r'(.+)-(dspark|plain)-edit-(\d+).json',capture.name)
    if not match:continue
    label,mode,depth=match.groups()
    equal=evidence/(label+'.equal')
    if not equal.is_file() or not equal.stat().st_size:continue
    data=json.loads(capture.read_bytes())
    slot=int(depth)+3200
    ref='p9-128k' if slot==131072 else f'p9-slot-{slot}'
    base=raw/f'{ref}-plain-edit-{depth}.json'
    orig=json.loads(base.read_bytes())
    t=data['timings']
    assert t['prompt_n']==int(depth) and t['predicted_n']==len(data['ids'])==3000
    assert data['ids']==orig['ids'] and data['message']==orig['message']
    if mode=='dspark':assert t['draft_n_accepted']>0
    p=raw/f'{label}-{mode}.vram';reader=list(csv.reader(p.read_text().splitlines(),skipinitialspace=True))
    used=[int(x[1]) for x in reader];peak=max(used);free=min(int(x[2]) for x in reader)
    ready=evidence/f'{label}-{mode}-ready.txt';start=int(ready.read_text().split(',')[1].split()[0])
    table=evidence/f'{label}-{mode}.txt'
    assert f'samples {len(reader)} peak used MiB {peak} min free MiB {free}' in table.read_text()
    digest=hashlib.sha256(struct.pack('<3000i',*data['ids'])).hexdigest()
    assert digest in equal.read_text()
    rows.append([slot,depth,label,mode,round(t['prompt_per_second'],3),round(t['predicted_per_second'],3),int(t.get('draft_n',0)),int(t.get('draft_n_accepted',0)),start,peak,free,len(used),digest])
    for item in (capture,base,p,raw/f'{label}-{mode}.server',table,ready,equal):files[item.name]=item
if rows:
    with (evidence/f'{name}-native.tsv').open('w') as f:
        writer=csv.writer(f,delimiter='\t',lineterminator='\n')
        writer.writerow(('slot','prompt','case','mode','prompt_tok_s','decode_tok_s','proposed','accepted','ready_proc_mib','peak_card_mib','min_free_mib','samples','ids_sha256'))
        writer.writerows(rows)
    with tarfile.open(evidence/f'{name}-native-captures.tar.gz','w:gz') as t:
        for k,p in files.items():t.add(p,arcname=k,recursive=False)
    with tarfile.open(evidence/f'{name}-native-captures.tar.gz') as t:
        assert all(t.extractfile(k).read()==p.read_bytes() for k,p in files.items())
    print(name,len(rows),'complete long captures, all 3000 IDs, messages and recorded VRAM samples verified.')
