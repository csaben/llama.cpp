set -euo pipefail
for layer in 0 5 12; do
    d="build/p11/window-native-$layer"
    mkdir -p "$d"
    B_MIN_FREE_MIB=14000 B_MR_TOOL="$PWD/build/p11/capture-windows" P11_LAYER=$layer P11_CAPTURE_WINDOWS=1 perf/p11/b/gpu.sh perf/p11/b/run.sh mr build/p11/managed/window-tokens.txt "$d" >"$d/out.txt" 2>"$d/log.txt"
    (cd "$d" && sha256sum {2..7}/{gate,down}.{input,ids,output}) >"$d/native.sha256"
    until [[ -s build/p11/window-capture-$layer/7/down.output ]]; do
        [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
        sleep 10
    done
    (cd "build/p11/window-capture-$layer" && sha256sum -c "$OLDPWD/$d/native.sha256") >"$d/control.txt"
    test "$(rg -c ': OK$' "$d/control.txt")" = 36
    mkdir -p perf/p11/b/screen/model-windows
    cp "$d/native.sha256" "perf/p11/b/screen/model-windows/layer-$layer-native.sha256"
done
