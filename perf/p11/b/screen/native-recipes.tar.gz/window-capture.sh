set -eu
for layer in 0 5 12; do
    d="build/p11/window-capture-$layer"
    mkdir -p "$d"
    if [[ -s "$d/7/down.output" ]]; then continue; fi
    export P11_LAYER=$layer P11_CAPTURE_WINDOWS=1 GGML_CUDA_ENABLE_UNIFIED_MEMORY=1 B_MIN_FREE_MIB=1200
    B_MR_TOOL="$PWD/build/p11/capture-windows" perf/p11/b/gpu.sh timeout -k 5 160 perf/p11/b/run.sh mr build/p11/managed/window-tokens.txt "$d" >"$d/out.txt" 2>"$d/log.txt"
done
