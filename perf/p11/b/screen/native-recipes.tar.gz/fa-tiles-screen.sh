set -euo pipefail
d=build/p11/prompt-attention-data
out=perf/p11/b/screen
mkdir -p "$d"
until [[ -s build/p11/fa-tiles-bin/libggml-cuda.so.1 ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP && $(date +%H%M) < 0730 ]] || exit 75
    sleep 10
done
run() {
    local label=$1 lib=$2 cols=$3 depth=$4 queries=$5
    local a="$d/$label-$depth-$queries"
    if [[ -s "$a.tsv" ]]; then return; fi
    B_MIN_FREE_MIB=1200 perf/p11/b/gpu.sh timeout -k 5 90 env LD_LIBRARY_PATH="$lib" P11_FA_COLS=$cols GGML_CUDA_GRAPH_CHUNK_SIZE=0 build/p11/prompt-attention "$depth" "$queries" "$a.f32" >"$a.times" 2>"$a.log"
    test "$(stat -c%s "$a.f32")" -eq "$((4*128*24*queries))"
    printf '%s\t%s\n' "$(cat "$a.times")" "$(sha256sum "$a.f32" | cut -d' ' -f1)" >"$a.tsv"
}
for shape in 4096x512 16384x512 65536x128; do
    depth=${shape%x*}; queries=${shape#*x}
    run old1 "$HOME/inkling-live-bin-p9-72fd097" 0 "$depth" "$queries"
    for cols in 8 16 32; do run "c$cols-new1" "$PWD/build/p11/fa-tiles-bin" "$cols" "$depth" "$queries"; done
    for cols in 32 16 8; do run "c$cols-new2" "$PWD/build/p11/fa-tiles-bin" "$cols" "$depth" "$queries"; done
    run old2 "$HOME/inkling-live-bin-p9-72fd097" 0 "$depth" "$queries"
done
"$HOME/llama.cpp-fast/.venv/bin/python" - "$d" "$out" <<'PY'
from pathlib import Path
from statistics import mean,median
import csv,sys
import numpy as np
d,out=map(Path,sys.argv[1:])
with (out/'prompt-attention-tiles.tsv').open('w') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n')
 w.writerow('kv queries tile old1_us new1_us new2_us old2_us old_mean_us new_mean_us delta_pct bit_equal max_abs_diff old_sha256 new_sha256'.split())
 for depth,queries in ((4096,512),(16384,512),(65536,128)):
  for cols in (8,16,32):
   legs=('old1',f'c{cols}-new1',f'c{cols}-new2','old2')
   cells=[d/f'{name}-{depth}-{queries}' for name in legs]
   rows=[p.with_suffix('.tsv').read_text().split() for p in cells]
   times=[median(map(float,r[3:-1])) for r in rows]; old=mean((times[0],times[3]));new=mean(times[1:3])
   sha=[r[-1] for r in rows];assert sha[0]==sha[3] and sha[1]==sha[2]
   vals=[np.fromfile(cells[i].with_suffix('.f32'),dtype='<f4') for i in (0,1)]
   diff=float(np.max(np.abs(vals[1]-vals[0])))
   w.writerow([depth,queries,cols,*times,round(old,3),round(new,3),round(100*(new/old-1),2),sha[0]==sha[1],diff,sha[0],sha[1]])
PY
