set -euo pipefail
file=ggml/src/ggml-cuda/fattn.cu
git diff --quiet -- "$file"
python3 - <<'PY'
from pathlib import Path
p=Path('ggml/src/ggml-cuda/fattn.cu');s=p.read_text()
old='''                ggml_cuda_flash_attn_ext_mma_f16_switch_ncols1<128, 128, 1, block_q8_0>(ctx, dst);'''
new='''                static const int cols = getenv("P11_FA_COLS") ? atoi(getenv("P11_FA_COLS")) : 0;
                switch (cols) {
                    case 8:  ggml_cuda_flash_attn_ext_mma_f16_case<128, 128, 8, 1, block_q8_0>(ctx, dst); break;
                    case 16: ggml_cuda_flash_attn_ext_mma_f16_case<128, 128, 16, 1, block_q8_0>(ctx, dst); break;
                    case 32: ggml_cuda_flash_attn_ext_mma_f16_case<128, 128, 32, 1, block_q8_0>(ctx, dst); break;
                    default: ggml_cuda_flash_attn_ext_mma_f16_switch_ncols1<128, 128, 1, block_q8_0>(ctx, dst); break;
                }'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
PY
git diff -- "$file" >build/p11/fa-tiles.patch
trap 'git apply -R build/p11/fa-tiles.patch' EXIT
cmake --build build -j8 --target ggml-cuda >build/p11/fa-tiles-build.log 2>&1
d=build/p11/fa-tiles-bin
mkdir -p "$d"
for f in build/p11/narrow-bin/*; do if [[ ${f##*/} != libggml-cuda.so.1 ]]; then ln -f "$f" "$d/"; fi; done
cp -L build/bin/libggml-cuda.so.1 "$d/"
git apply -R build/p11/fa-tiles.patch
trap - EXIT
cmake --build build -j8 --target ggml-cuda >build/p11/fa-tiles-clean.log 2>&1
