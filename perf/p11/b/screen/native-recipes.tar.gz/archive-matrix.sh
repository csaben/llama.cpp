set -euo pipefail
name=${1:?matrix name}
d="build/p11/matrix-$name"
dest="perf/p11/b/matrix-$name"
tmp=$(mktemp -d build/p11/matrix-audit.XXXXXX)
trap 'rm -rf "$tmp"' EXIT
python3 perf/p8bc/summarize.py "$d" >"$tmp/cells.tsv"
test "$(wc -l <"$tmp/cells.tsv")" -eq 195
cp "$tmp/cells.tsv" "$d/cells.tsv.$BASHPID"
mv "$d/cells.tsv.$BASHPID" "$d/cells.tsv"
python3 perf/p11/b/audit.py "$d" build/p11/matrix-p9 >"$tmp/audit.txt"
tar --exclude='*.log' --exclude='*.equal.*' -C "$d" -czf "$tmp/captures.tar.gz" main prose fixed
mkdir "$tmp/replay"
tar -xzf "$tmp/captures.tar.gz" -C "$tmp/replay"
python3 perf/p8bc/summarize.py "$tmp/replay" >"$tmp/replay/cells.tsv"
cmp "$tmp/cells.tsv" "$tmp/replay/cells.tsv"
python3 perf/p11/b/audit.py "$tmp/replay" build/p11/matrix-p9 | cmp - "$tmp/audit.txt"
mkdir -p "$dest"
mv "$tmp/cells.tsv" "$tmp/audit.txt" "$tmp/captures.tar.gz" "$dest/"
