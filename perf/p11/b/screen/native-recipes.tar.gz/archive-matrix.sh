set -euo pipefail
name=$1
d="build/p11/matrix-$name"
dest="perf/p11/b/matrix-$name"
mkdir -p "$dest"
python3 perf/p8bc/summarize.py "$d" >"$d/cells.tsv"
python3 perf/p11/b/audit.py "$d" build/p11/matrix-p9 >"$dest/audit.txt"
cp "$d/cells.tsv" "$dest/"
tar --exclude='*.log' -C "$d" -czf "$dest/captures.tar.gz" main prose fixed
