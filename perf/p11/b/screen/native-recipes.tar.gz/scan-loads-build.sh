set -euo pipefail
p=ggml/src/ggml-cuda/inkling.cu
git diff --quiet -- "$p"
for variant in late occ2 prefetch16 prefetch32; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
    python3 build/p11/scan-loads.py "$variant"
    patch="build/p11/scan-$variant.patch"
    git diff -- "$p" >"$patch"
    trap 'git apply -R "$patch"' EXIT
    CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >"build/p11/scan-build-$variant.log" 2>&1
    d="build/p11/scan-$variant-bin"
    mkdir -p "$d"
    for f in build/p11/release-bin/*; do if [[ ${f##*/} != libggml-cuda.so.1 ]]; then ln "$f" "$d/"; fi; done
    cp -L build/bin/libggml-cuda.so.1 "$d/"
    git apply -R "$patch"
    trap - EXIT
done
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >build/p11/scan-rebuild-clean.log 2>&1
