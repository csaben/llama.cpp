set -euo pipefail
lib=build/p11/ctrl-bin/libggml-cuda.so.1
until [[ -e build/p11/screen/ctrl0.log ]]; do
    [[ ! -e perf/STOP && ! -e /home/arelius/llama.cpp-fast/perf/STOP ]] || exit 75
    sleep 3
done
if ! LC_ALL=C rg -Ua -q 'P11B_CTRL_MATH' "$lib"; then
    git apply build/p11/controller-screen.patch
    CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >build/p11/ctrl-rebuild.log 2>&1
    cp -L build/bin/libggml-cuda.so.1 "$lib.new"
    LC_ALL=C rg -Ua -q 'P11B_CTRL_MATH' "$lib.new"
    mv "$lib.new" "$lib"
    git apply -R build/p11/controller-screen.patch
fi
sha256sum "$lib"
