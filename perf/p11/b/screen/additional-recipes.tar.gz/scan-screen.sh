set -eu
run=perf/p11/b/screen/scan.sh
"$run" base
IK_ATTN_MMA_SPLITS=6 "$run" splits6
IK_ATTN_MMA_SPLITS=14 "$run" splits14
IK_ATTN_MMA_SPLITS=24 "$run" splits24
IK_ATTN_MMA_SPW=2 "$run" spw2
IK_WINDOW_COLS=2 "$run" packed
IK_WINDOW_COLS=0 IK_ATTN_SCAN_MIN=2048 IK_WINDOW_SCAN_MIN=2048 "$run" external
IK_WINDOW_COLS=0 IK_WINDOW_TILE_ROWS=4 "$run" tiled
"$run" base2
