set -euo pipefail
p=ggml/src/ggml-cuda/inkling.cu
python3 - <<'PY'
from pathlib import Path
p=Path('ggml/src/ggml-cuda/inkling.cu');s=p.read_text();a='''    CUBLAS_CHECK(cublasSetMathMode(h, CUBLAS_DEFAULT_MATH));'''
assert s.count(a)==1
s=s.replace(a,'''#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA) && CUDART_VERSION >= 11000
    static const int mode = getenv("P11B_CTRL_MATH") ? atoi(getenv("P11B_CTRL_MATH")) : 0;
    if (mode && n_col >= 128 && ggml_cuda_info().devices[ctx.device].cc == GGML_CUDA_CC_AMPERE_GA10X) {
        CUBLAS_CHECK(cublasSetStream(h, ctx.stream()));
        CUBLAS_CHECK(cublasGemmEx(h, CUBLAS_OP_T, CUBLAS_OP_N, m, n_col, k, &one, a, CUDA_R_32F, lda,
            b, CUDA_R_32F, ldb, &zero, c, CUDA_R_32F, ldc, mode == 1 ? CUBLAS_COMPUTE_32F_FAST_TF32 : CUBLAS_COMPUTE_32F_FAST_16F, CUBLAS_GEMM_DEFAULT));
        return;
    }
#endif
'''+a);p.write_text(s)
PY
git diff -- "$p" >build/p11/controller-screen.patch
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 cmake --build build -j8 --target ggml-cuda >build/p11/controller-build.log 2>&1
cp -a build/p11/base-bin build/p11/ctrl-bin
cp -L build/bin/libggml-cuda.so.1 build/p11/ctrl-bin/
git apply -R build/p11/controller-screen.patch
export B_LIBS="$PWD/build/p11/ctrl-bin"
d=perf/p11/b/screen/controller
mkdir -p "$d"
for mode in 0 1 2; do
    export P11B_CTRL_MATH=$mode
    perf/p11/b/gpu.sh perf/p11/b/run.sh bench -p 4096 -n 0 -r 3 >"$d/pp-$mode.json" 2>"build/p11/screen/ctrl$mode.log"
    perf/p11/b/gpu.sh perf/p11/b/run.sh logits 4096 2 >"build/p11/ctrl-$mode.f32" 2>"build/p11/screen/ctrl-logits$mode.log"
    test "$(stat -c %s "build/p11/ctrl-$mode.f32")" = 1600464
    sha256sum "build/p11/ctrl-$mode.f32" >"$d/logits-$mode.sha256"
    perf/p11/b/gpu.sh perf/p11/b/run.sh ppl -c 2048 -b 2048 -ub 512 --chunks 8 >"build/p11/screen/ctrl-ppl$mode.log" 2>&1
    rg 'Final estimate:' "build/p11/screen/ctrl-ppl$mode.log" >"$d/ppl-$mode.txt"
done
