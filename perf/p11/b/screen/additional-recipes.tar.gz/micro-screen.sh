set -euo pipefail
old="$HOME/inkling-live-bin-p9-72fd097"
screen="$PWD/build/p11/screen-bin"
run=perf/p11/b/screen/micro.sh
if [[ "$1" == verify ]]; then
    for leg in old1 new1 new2 old2; do
        lib=$old
        if [[ $leg == new* ]]; then lib="$PWD/build/p11/verify-bin"; fi
        P11B_VERIFY=3 "$run" "$lib" verify "$leg"
    done
    exit
fi
"$run" "$old" tile old1
for j in 8 16 24 40 48 64 80 96; do
    P11B_Q2K_J=$j P11B_Q20_J=$j "$run" "$screen" tile "j$j"
done
for waves in default 1 2 4 8; do
    if [[ $waves == default ]]; then P11B_TILE_MIN=101 "$run" "$screen" tile stream; else
        P11B_TILE_MIN=101 P11B_STREAM_WAVES=$waves "$run" "$screen" tile "waves$waves"
    fi
done
for geom in i64-t128-o1 i64-t128-o3 i64-t128-o5 i32-t64-o4 i128-t256-o2 i128-t256-o3; do
    "$run" "$PWD/build/p11/geom-$geom" tile "$geom"
done
"$run" "$old" tile old2
