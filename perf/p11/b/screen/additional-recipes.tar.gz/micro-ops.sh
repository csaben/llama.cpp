set -euo pipefail
d=perf/p11/b/screen/ops
mkdir -p "$d" build/p11/ops
for spec in p9:tile release-bin:tile screen-bin:tile geom-i64-t128-o1:tile id-bin:tile fa-bin:flash bias-bin:bias p9:attention verify-bin:tile; do
    lib=${spec%:*}
    export B_LIBS="$PWD/build/p11/$lib" B_MIN_FREE_MIB=1000
    if [[ $lib == p9 ]]; then B_LIBS="$HOME/inkling-live-bin-p9-72fd097"; fi
    case ${spec#*:} in
        tile) op=MUL_MAT_ID; filter='m=257,n=512,k=512' ;;
        flash) op=FLASH_ATTN_EXT; filter='rel_bias=1' ;;
        bias) op=REL_BIAS; filter='n_tok=129,n_kv=1025' ;;
        attention) op=INKLING_ATTN; filter='type_kv=q8_0' ;;
    esac
    log="build/p11/ops/$lib-$op.log"
    P11B_VERIFY=3 perf/p11/b/gpu.sh perf/p11/b/run.sh ops -o "$op" -p "$filter" >"$log" 2>&1
    sed -E 's/\x1B\[[0-9;]*[mK]//g' "$log" | rg 'tests passed|Backend CUDA0:|FAIL' >"$d/$lib-$op.txt"
    rg -q ' [1-9][0-9]*/[1-9][0-9]* tests passed' "$d/$lib-$op.txt"
done
