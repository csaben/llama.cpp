set -eu
old="$HOME/inkling-live-bin-p9-72fd097"
for leg in old1 new1 new2 old2; do
    lib="$old"; if [[ $leg == new* ]]; then lib="$PWD/build/p11/screen-bin"; fi
    P11B_Q20_J=40 perf/p11/b/screen/micro.sh "$lib" tile "q20j40-$leg"
done
